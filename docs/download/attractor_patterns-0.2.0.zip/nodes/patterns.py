"""The 21 pattern families, as Geometry Nodes modifiers.

Each recipe mirrors the matching build() in the 2D playground
(siatohi80/attractor-patterns, index.html) so the same parameters give the
same pattern. Units are scene units; the defaults assume metres (24 mm cells).
"""

import math

from .dsl import Builder, new_tree, add_socket, io, menu
from . import core
from .core import PREFIX, poly_shapes, fill, cell_drop

TAU = 2.0 * math.pi


class Family:
    def __init__(self, key, name, group, drive, make, recipe, grid=None, align=False, solid=False,
                 drop_islands=True, extra=None):
        self.key, self.name, self.group, self.drive, self.make = key, name, group, drive, make
        self.recipe, self.grid, self.align, self.solid = recipe, grid, align, solid
        self.drop_islands, self.extra = drop_islands, extra or []

    @property
    def tree_name(self):
        return PREFIX + self.name


FAMILIES = []


def family(key, name, group, drive, make, **kw):
    def deco(fn):
        FAMILIES.append(Family(key, name, group, drive, make, fn, **kw))
        return fn
    return deco


# ----------------------------------------------------------------------
class Ctx:
    """What a recipe gets: the builder, parameters and shared-group shortcuts."""

    def __init__(self, b, gi, groups, plane):
        self.b, self.gi, self.g = b, gi, groups
        self.s = b.maxf(gi["Cell Size"], 1e-6)
        self.bridge = gi["Min Bridge"]
        self.minhole = gi["Min Hole"]
        self.corner = gi["Corner Radius"]
        self.seed = gi["Seed"]
        self.plane = plane
        self.S = plane["Scale"]
        self.mn, self.mx = plane["Min"], plane["Max"]
        self.falloff = None  # set by build_family
        self.combine = None

    def field_args(self):
        gi = self.gi
        return {"Attractor Points": gi["Attractor Points"], "Attractor Lines": gi["Attractor Lines"],
                "Radius": gi["Radius"], "Falloff": self.falloff, "Combine": self.combine, "Invert": gi["Invert"]}

    def sample(self, pts, remove_invalid=True):
        args = {"Points": pts, "Mesh": self.gi["Geometry"], "UV Map": self.gi["UV Map"], "Scale": self.S,
                "Remove Invalid": remove_invalid}
        args.update(self.field_args())
        return self.b.group(self.g["sample"], args).out(0)

    def cells(self, grid):
        pts = self.b.group(self.g["cells"], {"Min": self.mn, "Max": self.mx, "Cell Size": self.s, "Grid": grid}).out(0)
        return self.sample(pts)

    def density_mesh(self):
        """A fine grid over the pattern plane carrying the field, for density-driven seeding.

        The object's own mesh can be far too coarse to carry the field (a plane
        has four vertices), so seeding runs on this grid instead."""
        b = self.b
        grid, _, _ = self.grid_mesh(self.s / 2.0, cap=300.0)
        return self.sample(grid, remove_invalid=False)

    def poisson(self, mesh, dmin, factor):
        b = self.b
        valid = b.on_domain(b.switch(b.named("ap_valid", "BOOLEAN"), 0.0, 1.0), "FACE") > 0.999
        n = b.node("GeometryNodeDistributePointsOnFaces", {"Mesh": mesh, "Seed": self.seed, "Selection": valid},
                   distribute_method="POISSON")
        b.set(n, "Distance Min", dmin)
        b.set(n, "Density Max", 2.0 / (dmin * dmin))
        b.set(n, "Density Factor", factor)
        return n["Points"]

    def lattice(self, dx, dy, x0, y0, x1, y1, shift=0.0):
        """Unsampled points x0 + i*dx (+ shift on odd rows), y0 + j*dy, up to x1, y1.

        Stores the column and row as ap_i and ap_j, like the playground's
        nested for loops."""
        b = self.b
        nx = b.clamp(b.floor((x1 - x0) / dx) + 1.0, 1.0, 800.0)
        ny = b.clamp(b.floor((y1 - y0) / dy) + 1.0, 1.0, 800.0)
        to_i = lambda v: b.node("FunctionNodeFloatToInt", {"Float": v}, rounding_mode="ROUND").out(0)
        nxi = to_i(nx)
        idx = b.index()
        i = b.mod(idx, nxi)
        j = b.floor(idx / nxi)
        pos = b.vec(x0 + i * dx + b.mod(j, 2.0) * shift, y0 + j * dy, 0.0)
        pts = b.node("GeometryNodePoints", {"Count": to_i(nx * ny), "Position": pos}).out(0)
        pts = b.store(pts, "ap_i", i, kind="INT")
        return b.store(pts, "ap_j", j, kind="INT")

    def hex_lattice(self, pad_start=0.0):
        """The playground's hexCenters(): rows s*sqrt(3)/2 apart, odd rows shifted by s/2."""
        s = self.s
        h = s * (math.sqrt(3.0) / 2.0)
        return self.lattice(s, h, self.mn.x - pad_start, self.mn.y - pad_start * (math.sqrt(3.0) / 2.0),
                            self.mx.x + s, self.mx.y + h, shift=s / 2.0)

    def f(self):
        return self.b.named("ap_field")

    def grid_mesh(self, g, cap=400.0):
        """A quad grid covering the pattern plane's bounding box, spacing about g."""
        b = self.b
        size = self.mx - self.mn
        nx = b.clamp(b.math("CEIL", size.x / g), 1.0, cap)
        ny = b.clamp(b.math("CEIL", size.y / g), 1.0, cap)
        gx, gy = size.x / nx, size.y / ny
        to_i = lambda v: b.node("FunctionNodeFloatToInt", {"Float": v}, rounding_mode="ROUND").out(0)
        m = b.node("GeometryNodeMeshGrid", {"Size X": size.x, "Size Y": size.y,
                                            "Vertices X": to_i(nx + 1.0), "Vertices Y": to_i(ny + 1.0)}).out(0)
        m = b.node("GeometryNodeTransform", {"Geometry": m, "Translation": (self.mn + self.mx) * 0.5}).out(0)
        return m, gx, gy


# ----------------------------------------------------------------------
def circle_fn(b, radius, n=32):
    def fn(k):
        a = k * (TAU / n)
        return b.vec(b.cos(a) * radius(), b.sin(a) * radius(), 0.0)
    return fn


def rotate2(b, v, ang):
    c, s = b.cos(ang), b.sin(ang)
    return b.vec(v.x * c - v.y * s, v.x * s + v.y * c, 0.0)

def obround_fn(b, L, w, ang, half=12):
    """The playground's obround(): a slot of length L and width w, turned by ang. Uses 2*half vertices."""
    def fn(k):
        hl = b.maxf(L() / 2.0 - w() / 2.0, 0.0)
        right = k < half
        j = b.switch(right, k - half, k)
        th = j * (math.pi / (half - 1)) + b.switch(right, math.pi / 2.0, -math.pi / 2.0)
        cx = b.switch(right, hl * -1.0, hl)
        p = b.vec(cx + b.cos(th) * (w() / 2.0), b.sin(th) * (w() / 2.0), 0.0)
        return rotate2(b, p, ang())
    return fn


def dir2(b, a):
    return b.vec(b.cos(a), b.sin(a), 0.0)


@family("holes", "Round Perforation", "Grid + shape",
        "Hole diameter, so open area grades from solid to porous.",
        "Keep hole diameter at or above sheet thickness for punching, and the bridge between holes at least the sheet thickness.",
        grid=1)
def round_perforation(c):
    b = c.b
    cells = c.cells(1)
    r = lambda: (c.s - c.bridge) / 2.0 * c.f()
    cells = cell_drop(b, cells, (r() * 2.0 >= c.minhole) & (r() > c.s * 0.002))
    return poly_shapes(b, cells, 32, circle_fn(b, r))


@family("honey", "Honeycomb", "Tiling · car grille",
        "Wall thickness: thin walls (big cells) near the attractor, thick walls far away.",
        "Wall width is cell size minus opening; keep it at or above sheet thickness. Molded grilles need draft on the cell walls.",
        grid=1)
def honeycomb(c):
    b = c.b
    cells = c.cells(1)
    ri = lambda: (c.s - b.lerp(c.s * 0.75, c.bridge, c.f())) / 2.0
    cells = cell_drop(b, cells, (ri() * 2.0 >= c.minhole) & (ri() > c.s * 0.002))

    def fn(k):
        a = k * (math.pi / 3.0) + math.pi / 6.0
        R = ri() * (2.0 / math.sqrt(3.0))
        return b.vec(b.cos(a) * R, b.sin(a) * R, 0.0)
    return poly_shapes(b, cells, 6, fn, fillet=c.corner)


@family("diamond", "Diamond Mesh", "Tiling · car grille",
        "Opening size and squash: openings grow and turn square near the attractor.",
        "Acute corners concentrate stress and burn on laser cuts; keep a corner radius. Check the bridge where diamonds squash.",
        grid=2)
def diamond_mesh(c):
    b = c.b
    cells = c.cells(2)

    def dims():
        kmax = 1.0 - c.bridge * math.sqrt(2.0) / c.s
        hy = c.s / 2.0 * kmax * (c.f() * 0.88 + 0.12)
        hx = hy * b.lerp(0.55, 1.0, c.f())
        return hx, hy
    hx, hy = dims()
    india = hx * hy * 2.0 / b.sqrt(hx * hx + hy * hy + 1e-18)
    cells = cell_drop(b, cells, (india >= c.minhole) & (hy > c.s * 0.002))

    def fn(k):
        hx, hy = dims()
        return b.index_switch(k, [b.vec(0.0, -hy), b.vec(hx, 0.0), b.vec(0.0, hy), b.vec(-hx, 0.0)],
                              kind="VECTOR")
    return poly_shapes(b, cells, 4, fn, fillet=c.corner)


@family("jewel", "Jewel Studs", "3D texture · car grille",
        "Pyramid height, and the apex leans toward the attractor so facets catch light differently.",
        "Emboss depth is limited by material stretch; for molding keep draft angles on facets and avoid undercuts.",
        grid=0, solid=True)
def jewel_studs(c):
    b = c.b
    cells = c.cells(0)
    cells = b.store(cells, "ap_c", b.position(), kind="FLOAT_VECTOR")
    cone = b.node("GeometryNodeMeshCone", {"Vertices": 4, "Radius Top": 0.0, "Radius Bottom": 1.0, "Depth": 1.0},
                  fill_type="NGON").out(0)
    inst = b.node("GeometryNodeInstanceOnPoints", {"Points": cells, "Instance": cone}).out(0)
    m = b.node("GeometryNodeRealizeInstances", {"Geometry": inst}).out(0)
    f = c.f()
    ctr = b.named("ap_c", "FLOAT_VECTOR")
    local = b.position() - ctr
    q = c.s / 2.0 - c.bridge / 4.0
    apex = b.named("ap_dir2", "FLOAT_VECTOR") * (f * c.s * -0.28)
    is_apex = local.z > 0.0
    base = b.vec((local.x - local.y) * q, (local.x + local.y) * q, 0.0)
    m = b.store(m, "ap_lift", b.switch(is_apex, 0.0, c.s * (f * 0.5 + 0.08)))
    m = b.set_pos(m, ctr + b.switch(is_apex, base, apex, kind="VECTOR"))
    return m


@family("slots", "Rotating Slots", "Linear",
        "Slot angle (0 to 90°). With Align on, slots follow the attractor direction and grow near it.",
        "Rounded slot ends cut cleanly. Slot length is capped so neighbours keep the minimum bridge at any angle.",
        grid=0, align=True)
def rotating_slots(c):
    b = c.b
    cells = c.cells(0)
    align = c.gi["Align"]

    def dims():
        lm = b.minf(c.s * 0.92, c.s - c.bridge)
        w = b.minf(b.maxf(c.minhole, c.s * 0.26), lm)
        t2 = b.named("ap_tan2", "FLOAT_VECTOR")
        ang = b.switch(align, c.f() * (math.pi / 2.0), b.atan2(t2.y, t2.x))
        L = b.switch(align, lm, lm * (c.f() * 0.7 + 0.3))
        return L, w, ang
    L, _, _ = dims()
    cells = cell_drop(b, cells, L >= c.minhole)
    half = 12

    def fn(k):
        L, w, ang = dims()
        hl = b.maxf(L / 2.0 - w / 2.0, 0.0)
        right = k < half
        j = b.switch(right, k - half, k)
        th = j * (math.pi / (half - 1)) + b.switch(right, math.pi / 2.0, -math.pi / 2.0)
        cx = b.switch(right, hl * -1.0, hl)
        p = b.vec(cx + b.cos(th) * (w / 2.0), b.sin(th) * (w / 2.0), 0.0)
        return rotate2(b, p, ang)
    return poly_shapes(b, cells, 2 * half, fn)


@family("voronoi", "Voronoi Cells", "Cellular",
        "Cell density (small cells near the attractor) and wall thickness.",
        "Short Voronoi edges create slivers; small cells are removed and corners get the corner radius. Cells cut by the outline are left solid.")
def voronoi_cells(c):
    b = c.b
    pl = c.density_mesh()
    sep_lo = c.s * 0.55
    factor = (sep_lo / (c.s * b.lerp(1.5, 0.55, c.f()))) ** 2.0
    seeds = c.poisson(pl, sep_lo, factor)
    tri = delaunay(b, seeds, c.s)
    tri = b.store(tri, "ap_cc", circumcentre(b), kind="FLOAT_VECTOR", domain="FACE")
    dual = b.node("GeometryNodeDualMesh", {"Mesh": tri, "Keep Boundaries": False}).out(0)
    vor = b.set_pos(dual, b.named("ap_cc", "FLOAT_VECTOR"))
    vor = b.node("GeometryNodeSplitEdges", {"Mesh": vor}).out(0)
    vor = face_field(c, vor)
    area = b.node("GeometryNodeInputMeshFaceArea").out(0)
    ri = b.sqrt(area / math.pi)
    d = c.bridge / 2.0 + (1.0 - c.f()) * c.s * 0.12
    scale = b.maxf(1.0 - d / b.maxf(ri, 1e-12), 0.0)
    vor = b.store(vor, "ap_scale", scale, domain="FACE")
    vor = b.delete(vor, (ri * scale * 2.0) < c.minhole, domain="FACE")
    vor = b.node("GeometryNodeScaleElements", {"Geometry": vor, "Scale": b.named("ap_scale")},
                 domain="FACE", scale_mode="UNIFORM").out(0)
    curves = b.node("GeometryNodeMeshToCurve", {"Mesh": vor}).out(0)
    return fill(b, curves, fillet=c.corner)


@family("delaunay", "Triangulated Panels", "Cellular",
        "Opening size inside each triangle: large near the attractor, small far away.",
        "Thin triangles give unusable openings; anything below the minimum hole size is removed.")
def triangulated_panels(c):
    b = c.b
    pl = c.density_mesh()
    sep_lo = c.s * 0.85
    factor = (sep_lo / (c.s * b.lerp(2.0, 0.85, c.f()))) ** 2.0
    seeds = c.poisson(pl, sep_lo, factor)
    # seed the island outlines too, so triangles reach the edges (as the playground does)
    nb = b.node("GeometryNodeInputMeshEdgeNeighbors")["Face Count"]
    border = b.node("GeometryNodeMeshToCurve", {"Mesh": c.plane["Plane"], "Selection": b.cmp("EQUAL", nb, 1, dtype="INT")})
    border = b.node("GeometryNodeResampleCurve", {"Curve": border}, mode="LENGTH")
    b.set(border, "Length", c.s * 1.2)
    bpts = b.node("GeometryNodeCurveToPoints", {"Curve": border.out(0)}, mode="EVALUATED")["Points"]
    pts = b.join(seeds, bpts)
    pts = b.node("GeometryNodeMergeByDistance", {"Geometry": pts, "Distance": c.s * 0.05}).out(0)
    tri = delaunay(b, pts, c.s)
    tri = b.node("GeometryNodeSplitEdges", {"Mesh": tri}).out(0)
    tri = face_field(c, tri)
    A, B, C = corners(b)
    la, lb, lc = b.length(B - C), b.length(C - A), b.length(A - B)
    P = la + lb + lc
    area = b.node("GeometryNodeInputMeshFaceArea").out(0)
    ri = area * 2.0 / b.maxf(P, 1e-12)
    inc = (A * la + B * lb + C * lc) / b.maxf(P, 1e-12)
    d = c.bridge / 2.0 + (1.0 - (c.f() * 0.8 + 0.2)) * b.maxf(ri - c.bridge / 2.0, 0.0)
    scale = b.maxf((ri - d) / b.maxf(ri, 1e-12), 0.0)
    tri = b.store(tri, "ap_scale", scale, domain="FACE")
    tri = b.store(tri, "ap_inc", inc, kind="FLOAT_VECTOR", domain="FACE")
    tri = b.delete(tri, ((ri - d) * 2.0) < c.minhole, domain="FACE")
    tri = b.node("GeometryNodeScaleElements", {"Geometry": tri, "Scale": b.named("ap_scale"),
                                               "Center": b.named("ap_inc", "FLOAT_VECTOR")},
                 domain="FACE", scale_mode="UNIFORM").out(0)
    curves = b.node("GeometryNodeMeshToCurve", {"Mesh": tri}).out(0)
    return fill(b, curves, fillet=c.corner)


@family("morph", "Shape Morph", "Grid + shape",
        "Blend from circle (far) to rounded square (near), plus size.",
        "Square shapes have tighter corner gaps than circles; the bridge is checked at the corners, not only between centres.",
        grid=0)
def shape_morph(c):
    b = c.b
    cells = c.cells(0)
    r = lambda: (c.s - c.bridge) / 2.0 * (c.f() * 0.6 + 0.4)
    cells = cell_drop(b, cells, r() * 2.0 >= c.minhole)
    n = 48

    def fn(k):
        t = k * (TAU / n)
        e = 2.0 / b.lerp(2.0, 9.0, c.f())
        co, si = b.cos(t), b.sin(t)
        x = b.sign(co) * (b.absf(co) ** e) * r()
        y = b.sign(si) * (b.absf(si) ** e) * r()
        return b.vec(x, y, 0.0)
    return poly_shapes(b, cells, n, fn)


@family("star", "Star Tiling", "Tiling",
        "Star sharpness: near-octagons far away, pointed eight-point stars near the attractor.",
        "Pointed tips leave thin straps; use a corner radius for laser and waterjet.",
        grid=0)
def star_tiling(c):
    b = c.b
    cells = c.cells(0)
    ro = (c.s - c.bridge) / 2.0
    ri = lambda: ro * b.lerp(0.92, 0.42, c.f())
    area = ro * ri() * (8.0 * math.sin(math.pi / 8.0))
    per = b.sqrt(ro * ro + ri() * ri() - ro * ri() * (2.0 * math.cos(math.pi / 8.0))) * 16.0
    cells = cell_drop(b, cells, area * 4.0 / per >= c.minhole)

    def fn(k):
        a = k * (math.pi / 8.0)
        rad = b.switch(b.mod(k, 2.0) > 0.5, ro, ri())
        return b.vec(b.cos(a) * rad, b.sin(a) * rad, 0.0)
    return poly_shapes(b, cells, 16, fn, fillet=c.corner)


@family("truchet", "Truchet Arcs", "Tiling",
        "Whether a tile appears, its slot width, and (with Align) its orientation.",
        "Connected arcs can leave islands that fall out when cut. Use as engraving, or check every solid region stays attached.",
        grid=0, align=True)
def truchet_arcs(c):
    b = c.b
    cells = c.cells(0)
    cells = cell_drop(b, cells, c.f() >= 0.12)
    cells = b.store(cells, "ap_cell", b.index(), kind="INT")
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": cells, "Amount": 2}, domain="POINT")
    arcs = b.store(dup["Geometry"], "ap_arc", dup["Duplicate Index"], kind="INT")
    n = 22

    def fn(k):
        s = c.s
        t2 = b.named("ap_tan2", "FLOAT_VECTOR")
        rnd = b.random(0.0, 1.0, b.named("ap_cell", "INT"), c.seed)
        A = b.switch(c.gi["Align"], rnd < 0.5, (t2.x * t2.y) > 0.0, kind="BOOLEAN")
        second = b.cmp("EQUAL", b.named("ap_arc", "INT"), 1, dtype="INT")
        h = s / 2.0
        ox = b.switch(A, b.switch(second, h, -h), b.switch(second, -h, h))
        oy = b.switch(second, h, -h)
        a0 = b.switch(A, b.switch(second, math.pi / 2.0, -math.pi / 2.0), b.switch(second, 0.0, math.pi))
        w = b.maxf(c.minhole, b.lerp(c.minhole, s * 0.24, c.f()))
        outer = k < 11
        j = b.switch(outer, 21.0 - k, k)
        rad = b.switch(outer, h - w / 2.0, h + w / 2.0)
        a = a0 + j * (math.pi / 20.0)
        return b.vec(ox + b.cos(a) * rad, oy + b.sin(a) * rad, 0.0)
    return poly_shapes(b, arcs, n, fn)


@family("contours", "Flow Lines", "Line-based",
        "Line spacing (tight near the attractor) and groove width.",
        "As grooves, tool radius sets the minimum spacing. As cut slots, add tabs so strips stay attached.",
        drop_islands=False)
def flow_lines(c):
    b = c.b
    grid, gx, gy = c.grid_mesh(c.s / 8.0)
    grid = c.sample(grid, remove_invalid=False)
    grid = b.store(grid, "ap_val", contour_value(c))
    f = c.f()
    w = b.maxf(c.minhole, c.s * 0.025) * b.lerp(1.0, 2.2, f)
    delta = w / (c.s * b.lerp(1.6, 0.4, f) * 2.0)
    lvl = b.math("ROUND", b.on_domain(b.named("ap_val"), "FACE"))
    grid = b.store(grid, "ap_lo", lvl - b.on_domain(delta, "FACE"), domain="FACE")
    grid = b.store(grid, "ap_hi", lvl + b.on_domain(delta, "FACE"), domain="FACE")
    return iso_band(b, grid)


@family("packing", "Circle Packing", "Packing",
        "Circle size: small, tightly packed circles near the attractor.",
        "Gaps between circles never drop below the minimum bridge; circles below the minimum hole are removed.")
def circle_packing(c):
    """Dart throwing in size bands, largest first.

    Each band seeds Poisson points spaced for its largest circle, keeps those
    whose target radius falls in the band, and rejects any that come closer
    than the minimum bridge to circles already placed. Like the playground's
    dart(), every circle gets exactly its field-driven radius.
    """
    b = c.b
    grid = c.density_mesh()
    rmax, rmin = c.s * 0.75, c.s * 0.16
    target = lambda: b.lerp(rmax, rmin, c.f())
    bands, passes = 10, 4
    edges = [b.math("MULTIPLY", c.s, 0.75 * (0.16 / 0.75) ** (k / bands)) for k in range(bands + 1)]
    placed = None
    disks = None
    for k in [k for k in range(bands) for _ in range(passes)]:
        hi, lo = edges[k], edges[k + 1]
        in_band = b.on_domain(b.switch((target() <= hi) & (target() >= lo * 0.999), 0.0, 1.0), "FACE") > 0.0
        valid = b.on_domain(b.switch(b.named("ap_valid", "BOOLEAN"), 0.0, 1.0), "FACE") > 0.999
        n = b.node("GeometryNodeDistributePointsOnFaces", {"Mesh": grid, "Seed": c.seed + len(b._order),
                                                           "Selection": in_band & valid},
                   distribute_method="POISSON")
        sp = hi * 2.0 + c.bridge
        b.set(n, "Distance Min", sp)
        b.set(n, "Density Max", 4.0 / (sp * sp))
        pts = c.sample(n["Points"])
        pts = b.store(pts, "ap_r", target())
        pts = b.delete(pts, (b.named("ap_r") > hi) | (b.named("ap_r") < lo * 0.999))
        if disks is not None:
            prox = b.node("GeometryNodeProximity", {"Geometry": disks}, target_element="FACES")
            b.set(prox, "Sample Position", b.position())
            pts = b.delete(pts, prox["Distance"] < b.named("ap_r") + c.bridge)
        placed = pts if placed is None else b.join(placed, pts)
        disk = b.node("GeometryNodeMeshCircle", {"Vertices": 24, "Radius": 1.0}, fill_type="NGON").out(0)
        inst = b.node("GeometryNodeInstanceOnPoints", {"Points": placed, "Instance": disk,
                                                        "Scale": b.named("ap_r")}).out(0)
        disks = b.node("GeometryNodeRealizeInstances", {"Geometry": inst}).out(0)
    r = lambda: b.named("ap_r")
    placed = cell_drop(b, placed, r() * 2.0 >= c.minhole)
    return poly_shapes(b, placed, 32, circle_fn(b, r))


@family("halftone", "Halftone", "Image-based",
        "Dot size from an image, multiplied by the attractor field. Pick the image in the modifier.",
        "Dots below the minimum hole size are dropped rather than shrunk further; cap open area so the panel stays stiff.",
        grid=1, extra=[("Image", "IMG", None)])
def halftone(c):
    b = c.b
    cells = c.cells(1)
    uv = b.position() / c.S
    col = b.node("GeometryNodeImageTexture", {"Image": c.gi["Image"], "Vector": uv}).out(0)
    rgb = b.node("FunctionNodeSeparateColor", {"Color": col})
    lum = rgb.out(0) * 0.299 + rgb.out(1) * 0.587 + rgb.out(2) * 0.114
    cells = b.store(cells, "ap_dark", 1.0 - lum)
    r = lambda: (c.s - c.bridge) / 2.0 * (c.f() * 0.85 + 0.15) * (b.named("ap_dark") * 0.88 + 0.12)
    cells = cell_drop(b, cells, r() * 2.0 >= c.minhole)
    return poly_shapes(b, cells, 32, circle_fn(b, r))


@family("strut", "Strut Lattice", "Tiling",
        "Strut width: thin struts and big triangular openings near the attractor; far away the nodes swell into round lobes and the openings close up.",
        "The struts are the solid part; keep their thinnest width at or above the minimum bridge. Large corner rounding keeps the lobes smooth for laser and waterjet.")
def strut_lattice(c):
    b = c.b
    s = c.s
    h = s * (math.sqrt(3.0) / 2.0)
    pts = c.lattice(s, h, c.mn.x - s, c.mn.y - h, c.mx.x + s, c.mx.y + h, shift=s / 2.0)
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": pts, "Amount": 2}, domain="POINT")
    tris = b.store(dup["Geometry"], "ap_up", dup["Duplicate Index"], kind="INT")
    up = b.cmp("EQUAL", b.named("ap_up", "INT"), 0, dtype="INT")
    # centroids of the up triangle (x,y)(x+s,y)(x+s/2,y+h) and the down one (x+s,y)(x+s/2,y+h)(x+1.5s,y+h)
    tris = b.set_pos(tris, offset=b.switch(up, b.vec(s, h * (2.0 / 3.0), 0.0), b.vec(s / 2.0, h / 3.0, 0.0),
                                           kind="VECTOR"))
    tris = c.sample(tris)
    rin = s / (2.0 * math.sqrt(3.0))
    r = lambda: rin - b.lerp(s * 0.42, c.bridge, c.f()) / 2.0
    tris = cell_drop(b, tris, (r() > s * 0.002) & (r() * 2.0 >= c.minhole))

    def fn(k):
        a = k * (TAU / 3.0) + b.switch(up, -math.pi / 2.0, math.pi / 2.0)
        return dir2(b, a) * (r() * 2.0)
    return poly_shapes(b, tris, 3, fn, fillet=b.lerp(s * 0.2, s * 0.04, c.f()), fillet_count=8)


@family("ytiles", "Y Tiles", "Tiling",
        "Arm length and width: Y shapes grow and thicken near the attractor.",
        "Inner corners of the Y are sharp; the corner radius softens them. Arm tips keep the minimum bridge to the next row.")
def y_tiles(c):
    b = c.b
    s = c.s
    cells = c.sample(c.hex_lattice())
    L = lambda: (s / math.sqrt(3.0) - c.bridge) * (c.f() * 0.65 + 0.35)
    w = lambda: b.maxf(c.minhole, b.lerp(s * 0.08, s * 0.2, c.f()))
    cells = cell_drop(b, cells, (c.f() > 0.02) & (L() >= c.minhole))

    def fn(k):
        i = b.floor(k / 3.0)
        m = b.mod(k, 3.0)
        a = i * (TAU / 3.0) + math.pi / 2.0
        n = b.vec(-b.sin(a), b.cos(a), 0.0)
        tip = dir2(b, a) * L()
        ci = (w() / 2.0) / math.sin(math.pi / 3.0)
        return b.index_switch(m, [tip - n * (w() / 2.0), tip + n * (w() / 2.0),
                                  dir2(b, a + math.pi / 3.0) * ci], kind="VECTOR")
    return poly_shapes(b, cells, 9, fn, fillet=c.corner)


@family("nesthex", "Nested Hexagons", "Tiling",
        "Ring width: hexagon rings open up near the attractor (a second, inner ring appears) and thin to hairlines far away.",
        "Each ring is cut as six segments with a bridge at every corner, so the centre stays attached. Use as grooves if you want closed rings.")
def nested_hexagons(c):
    b = c.b
    s = c.s
    k3 = 2.0 / math.sqrt(3.0)
    cells = c.sample(c.hex_lattice())
    Ro = (s - c.bridge) / math.sqrt(3.0)
    w1 = lambda: Ro * 0.26 * c.f()
    cells = cell_drop(b, cells, (w1() > s * 0.002) & (w1() >= c.minhole))
    # 12 segments per cell: six on the outer ring, six on the inner one
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": cells, "Amount": 12}, domain="POINT")
    segs = b.store(dup["Geometry"], "ap_seg", dup["Duplicate Index"], kind="INT")
    seg = b.named("ap_seg", "INT")
    inner = seg >= 6
    Ri1 = lambda: Ro - w1() * k3
    R2 = lambda: Ri1() - b.maxf(c.bridge, w1() * 0.9) * k3
    w2 = lambda: w1() * 0.8
    segs = b.delete(segs, inner & ~((w2() >= c.minhole) & ((R2() - w2() * k3) > c.bridge)))
    R = lambda: b.switch(inner, Ro, R2())
    Ri = lambda: R() - b.switch(inner, w1(), w2()) * k3

    def fn(k):
        a0 = b.mod(seg, 6.0) * (math.pi / 3.0) + math.pi / 6.0
        a1 = a0 + math.pi / 3.0
        e = b.normalize(dir2(b, a1) - dir2(b, a0)) * (c.bridge / 2.0)
        o0, o1 = dir2(b, a0) * R(), dir2(b, a1) * R()
        i0, i1 = dir2(b, a0) * Ri(), dir2(b, a1) * Ri()
        return b.index_switch(k, [o0 + e, o1 - e, i1 - e, i0 + e], kind="VECTOR")
    return poly_shapes(b, segs, 4, fn, fillet=c.corner)


@family("sunflower", "Sunflower", "Spiral",
        "Dot size along a golden-angle (Fibonacci) spiral centred on the surface: dots grow near the attractor.",
        "Spacing is even across the spiral, so the bridge only depends on the largest dot; dots below the minimum hole are removed.")
def sunflower(c):
    b = c.b
    cs = c.s * 0.62
    ga = math.pi * (3.0 - math.sqrt(5.0))
    ctr = (c.mn + c.mx) * 0.5
    rmax_spiral = b.length(c.mx - c.mn) / 2.0
    n = b.clamp(b.math("CEIL", (rmax_spiral / cs) ** 2.0), 1.0, 400000.0)
    count = b.node("FunctionNodeFloatToInt", {"Float": n}, rounding_mode="ROUND").out(0)
    k = b.index() + 1.0
    pos = ctr + dir2(b, k * ga) * (b.sqrt(k) * cs)
    pts = b.node("GeometryNodePoints", {"Count": count, "Position": pos}).out(0)
    pts = c.sample(pts)
    r = lambda: (cs * 1.75 - c.bridge) / 2.0 * c.f()
    pts = cell_drop(b, pts, (r() > c.s * 0.002) & (r() * 2.0 >= c.minhole))
    return poly_shapes(b, pts, 32, circle_fn(b, r))


@family("herring", "Herringbone Slots", "Linear",
        "Slot length and width: rows lean alternately left and right, and slots grow near the attractor.",
        "Rounded slot ends cut cleanly. Length is capped so slots in neighbouring rows keep the minimum bridge.")
def herringbone(c):
    b = c.b
    s = c.s
    pts = c.lattice(s / 1.6, s / 2.0, c.mn.x + s / 2.0, c.mn.y + s / 4.0, c.mx.x, c.mx.y)
    pts = c.sample(pts)
    L = lambda: b.lerp(s * 0.25, s * 0.62, c.f())
    w = lambda: b.maxf(c.minhole, b.lerp(s * 0.12, s * 0.2, c.f()))
    ang = lambda: b.switch(b.mod(b.named("ap_j", "INT"), 2.0) > 0.5, -math.pi / 4.0, math.pi / 4.0)
    pts = cell_drop(b, pts, (c.f() > 0.02) & (L() >= c.minhole))
    return poly_shapes(b, pts, 24, obround_fn(b, L, w, ang))


@family("pinwheel", "Pinwheel Slits", "Linear",
        "Twist and size: lens slits on a triangle grid turn into pinwheels and grow near the attractor.",
        "Lens tips are sharp; the corner radius rounds them. Slits are capped so tips keep the minimum bridge when twisted.")
def pinwheel_slits(c):
    b = c.b
    s = c.s
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": c.hex_lattice(), "Amount": 3}, domain="POINT")
    pts = b.store(dup["Geometry"], "ap_a", dup["Duplicate Index"] * (math.pi / 3.0))
    a = lambda: b.named("ap_a")
    pts = b.set_pos(pts, offset=dir2(b, a()) * (s / 2.0))
    pts = c.sample(pts)
    L = lambda: b.lerp(s * 0.3, s * 0.62, c.f())
    W = lambda: b.maxf(c.minhole, b.lerp(s * 0.06, s * 0.16, c.f()))
    pts = cell_drop(b, pts, (c.f() > 0.02) & (L() >= c.minhole))
    half = 8

    def fn(k):
        L_, W_ = L(), W()
        R = (L_ * L_ / 4.0 + W_ * W_ / 4.0) / W_
        d = R - W_ / 2.0
        ha = b.math("ARCSINE", b.clamp(L_ / 2.0 / R, 0.0, 1.0))
        first = k < half
        i = b.mod(k, float(half))
        t = ha * -1.0 + ha * 2.0 * i / float(half)
        u = b.sin(t) * R
        v = b.cos(t) * R - d
        p = b.vec(b.switch(first, u * -1.0, u), b.switch(first, v * -1.0, v), 0.0)
        return rotate2(b, p, a() + math.pi / 2.0 + c.f() * (math.pi / 4.0))
    return poly_shapes(b, pts, 2 * half, fn, fillet=c.corner)


@family("xdiamond", "Cross-slot Diamonds", "Linear",
        "Slot length: slots at ±45° grow near the attractor until they meet as diamond outlines.",
        "Slot ends are rounded. The cap on length keeps a bridge where four slots meet at a diamond corner.")
def cross_slot_diamonds(c):
    b = c.b
    s = c.s * 0.75
    pts = c.lattice(s, s, c.mn.x + s / 2.0, c.mn.y + s / 2.0, c.mx.x, c.mx.y)
    pts = c.sample(pts)
    w = lambda: b.maxf(c.minhole, s * 0.14)
    L = lambda: b.lerp(s * 0.3, s * math.sqrt(2.0) - c.bridge * 1.6 - w(), c.f())
    odd = lambda: b.mod(b.named("ap_i", "INT") + b.named("ap_j", "INT"), 2.0) > 0.5
    ang = lambda: b.switch(odd(), -math.pi / 4.0, math.pi / 4.0)
    pts = cell_drop(b, pts, (c.f() > 0.02) & (L() >= c.minhole))
    return poly_shapes(b, pts, 24, obround_fn(b, lambda: L() + w(), w, ang))


@family("rd", "Reaction Diffusion", "Simulation",
        "Feed and kill rates: spots far away turn into stripes and mazes near the attractor.",
        "Best for 3D printing, CNC relief or engraving. Features smaller than your tool or nozzle need filtering.",
        drop_islands=False, extra=[("Iterations", "INT", 1500), ("Resolution", "FLOAT", 14.0)])
def reaction_diffusion(c):
    b = c.b
    g = c.s / b.maxf(c.gi["Resolution"], 1.0)
    grid, gx, gy = c.grid_mesh(g, cap=300.0)
    grid = c.sample(grid, remove_invalid=False)
    # neighbour indices, found once (masked neighbours fall back to the cell itself)
    pos = b.position()
    valid = b.named("ap_valid", "BOOLEAN")
    for name, off in (("ap_nl", (-1, 0)), ("ap_nr", (1, 0)), ("ap_nd", (0, -1)), ("ap_nu", (0, 1))):
        at = pos + b.vec(gx * off[0], gy * off[1], 0.0)
        ni = b.node("GeometryNodeSampleNearest", {"Geometry": grid, "Sample Position": at}, domain="POINT").out(0)
        ok = b.sample_index(grid, valid, ni, kind="BOOLEAN") & (b.vmath("DISTANCE", b.sample_index(
            grid, pos, ni, kind="FLOAT_VECTOR"), at) < b.minf(gx, gy) * 0.5)
        grid = b.store(grid, name, b.switch(ok, b.index(), ni, kind="INT"), kind="INT")
    f = c.f()
    grid = b.store(grid, "ap_F", b.lerp(0.0367, 0.029, f))
    grid = b.store(grid, "ap_K", b.lerp(0.0649, 0.057, f))
    # seed 5x5 patches at random, about 70 over the playground's sheet
    i = b.floor((pos.x - c.mn.x) / gx / 5.0)
    j = b.floor((pos.y - c.mn.y) / gy / 5.0)
    count = b.stat(grid, 1.0)["Sum"]
    p = b.minf(70.0 * 25.0 / b.maxf(count, 1.0), 0.5)
    seeded = (b.random(0.0, 1.0, b.node("FunctionNodeFloatToInt", {"Float": i + j * 7919.0}).out(0), c.seed) < p) & valid
    grid = b.store(grid, "ap_u", b.switch(seeded, 1.0, 0.5))
    grid = b.store(grid, "ap_v", b.switch(seeded, 0.0, 0.25))
    zi, zo = core._repeat(b, grid, c.gi["Iterations"], [])
    gg = zi["Geometry"]

    def nb(attr, which):
        return b.sample_index(gg, b.named(attr), b.named(which, "INT"))
    U, V = b.named("ap_u"), b.named("ap_v")
    lu = nb("ap_u", "ap_nl") + nb("ap_u", "ap_nr") + nb("ap_u", "ap_nd") + nb("ap_u", "ap_nu") - U * 4.0
    lv = nb("ap_v", "ap_nl") + nb("ap_v", "ap_nr") + nb("ap_v", "ap_nd") + nb("ap_v", "ap_nu") - V * 4.0
    uvv = U * V * V
    F, K = b.named("ap_F"), b.named("ap_K")
    u2 = U + (lu * 0.2 - uvv + F * (1.0 - U))
    v2 = V + (lv * 0.1 + uvv - (F + K) * V)
    u2 = b.switch(valid, 1.0, u2)
    v2 = b.switch(valid, 0.0, v2)
    g2 = b.store(gg, "ap_u2", u2)
    g2 = b.store(g2, "ap_v2", v2)
    g2 = b.store(g2, "ap_u", b.named("ap_u2"))
    g2 = b.store(g2, "ap_v", b.named("ap_v2"))
    b.set(zo, "Geometry", g2)
    grid = zo["Geometry"]
    grid = b.store(grid, "ap_val", b.named("ap_v"))
    grid = b.store(grid, "ap_lo", 0.22, domain="FACE")
    grid = b.store(grid, "ap_hi", 1.0e9, domain="FACE")
    return iso_band(b, grid)


# ----------------------------------------------------------------------
# geometry helpers

def corners(b):
    """Positions of a triangle's three corners, as face-domain fields."""
    out = []
    for k in range(3):
        ci = b.node("GeometryNodeCornersOfFace", {"Face Index": b.index(), "Sort Index": k})["Corner Index"]
        vi = b.node("GeometryNodeVertexOfCorner", {"Corner Index": ci}).out(0)
        out.append(b.sample_index(_self_geo(b), b.position(), vi, kind="FLOAT_VECTOR"))
    return out


def _self_geo(b):
    # Sample Index needs the geometry being evaluated; recipes call corners()
    # right after setting b.current to that geometry.
    return b.current


def delaunay(b, pts, s):
    """2D Delaunay triangulation of points in the plane: the lower convex hull of the lifted paraboloid."""
    ctr = b.node("GeometryNodeBoundBox", {"Geometry": pts})
    mid = (ctr["Min"] + ctr["Max"]) * 0.5
    rel = b.position() - mid
    lifted = b.set_pos(pts, b.vec(rel.x, rel.y, (rel.x * rel.x + rel.y * rel.y) / s))
    hull = b.node("GeometryNodeConvexHull", {"Geometry": lifted}).out(0)
    hull = b.delete(hull, b.normal().z >= 0.0, domain="FACE", mode="ALL")
    flat = b.set_pos(hull, b.vec(b.position().x, b.position().y, 0.0) + b.vec(mid.x, mid.y, 0.0))
    b.current = flat
    return flat


def circumcentre(b):
    A, B, C = corners(b)
    bb, cc = B - A, C - A
    d = (bb.x * cc.y - bb.y * cc.x) * 2.0
    d = b.switch(b.absf(d) < 1e-18, d, 1e-18)
    b2 = bb.x * bb.x + bb.y * bb.y
    c2 = cc.x * cc.x + cc.y * cc.y
    ux = (cc.y * b2 - bb.y * c2) / d
    uy = (bb.x * c2 - cc.x * b2) / d
    return A + b.vec(ux, uy, 0.0)


def face_field(c, mesh):
    """Store the attractor field of each face centre as a face attribute ap_field."""
    b = c.b
    pts = b.node("GeometryNodeMeshToPoints", {"Mesh": mesh}, mode="FACES").out(0)
    pts = c.sample(pts, remove_invalid=False)
    f = b.sample_index(pts, b.named("ap_field"), b.index())
    mesh = b.store(mesh, "ap_field", f, domain="FACE")
    b.current = mesh
    return mesh


def contour_value(c):
    """Line index of the flow-line field at each point: the integral of 1/spacing over distance.

    spacing(d) = s * lerp(1.6, 0.4, falloff(d)); integrated numerically up to the
    radius (four radii for inverse square), constant beyond. No attractors: straight rows.
    """
    b = c.b
    s = c.s
    R = c.gi["Radius"]
    d = b.named("ap_dist")
    cap = R * b.switch(b.cmp("EQUAL", c.falloff, 3, dtype="INT"), 1.0, 4.0)
    dm = b.minf(d, cap)
    steps = 24
    total = None

    def spacing(at):
        v = b.group(c.g["falloff"], {"Distance": at, "Radius": R, "Falloff": c.falloff}).out(0)
        v = b.switch(c.gi["Invert"], v, 1.0 - v)
        return s * b.lerp(1.6, 0.4, v)
    for k in range(steps):
        term = (dm / steps) / spacing(dm * ((k + 0.5) / steps))
        total = term if total is None else total + term
    total = total + b.maxf(d - cap, 0.0) / spacing(cap)
    none = d > core.BIG * 0.5
    return b.switch(none, total, b.position().y / s)


def iso_band(b, grid):
    """Polygons of the region lo < ap_val < hi on a quad grid (lo/hi per face).

    Per face: walk the 4 edges; each contributes its start corner (if inside)
    and up to two level crossings in order. That is a 12-slot polygon; empty
    slots are dropped, and neighbouring faces share crossing points exactly,
    so merging by distance welds the pieces into clean regions.
    """
    cs, vs = [], []
    for k in range(4):
        ci = b.node("GeometryNodeCornersOfFace", {"Face Index": b.index(), "Sort Index": k})["Corner Index"]
        vi = b.node("GeometryNodeVertexOfCorner", {"Corner Index": ci}).out(0)
        cs.append(b.sample_index(grid, b.position(), vi, kind="FLOAT_VECTOR"))
        vs.append(b.sample_index(grid, b.named("ap_val"), vi))
    for k in range(4):
        grid = b.store(grid, f"ap_c{k}", cs[k], kind="FLOAT_VECTOR", domain="FACE")
        grid = b.store(grid, f"ap_v{k}", vs[k], domain="FACE")
    lo, hi = b.named("ap_lo"), b.named("ap_hi")
    v = [b.named(f"ap_v{k}") for k in range(4)]
    vmin = b.minf(b.minf(v[0], v[1]), b.minf(v[2], v[3]))
    vmax = b.maxf(b.maxf(v[0], v[1]), b.maxf(v[2], v[3]))
    touch = (vmax > lo) & (vmin < hi)
    pts = b.node("GeometryNodeMeshToPoints", {"Mesh": grid, "Selection": touch}, mode="FACES").out(0)
    pts = b.store(pts, "ap_id", b.index(), kind="INT")
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": pts, "Amount": 12}, domain="POINT")
    pts = b.store(dup["Geometry"], "ap_k", dup["Duplicate Index"], kind="INT")
    k = b.named("ap_k", "INT")
    e = b.node("FunctionNodeFloatToInt", {"Float": b.floor(k / 3.0)}).out(0)
    j = b.mod(k, 3.0)
    C = [b.named(f"ap_c{q}", "FLOAT_VECTOR") for q in range(4)]
    Vv = [b.named(f"ap_v{q}") for q in range(4)]
    A = b.index_switch(e, C, kind="VECTOR")
    Bp = b.index_switch(e, C[1:] + C[:1], kind="VECTOR")
    va = b.index_switch(e, Vv)
    vb = b.index_switch(e, Vv[1:] + Vv[:1])
    lo, hi = b.named("ap_lo"), b.named("ap_hi")
    den = vb - va
    den = b.switch(b.absf(den) < 1e-12, den, 1e-12)
    tl, th = (lo - va) / den, (hi - va) / den
    tl = b.switch((tl > 0.0) & (tl < 1.0), 2.0, tl)
    th = b.switch((th > 0.0) & (th < 1.0), 2.0, th)
    t = b.switch(j > 1.5, b.minf(tl, th), b.maxf(tl, th))
    corner_in = (va >= lo) & (va <= hi)
    valid = b.switch(j < 0.5, t < 1.5, corner_in, kind="BOOLEAN")
    t = b.switch(j < 0.5, t, 0.0)
    pts = b.set_pos(pts, A + (Bp - A) * t)
    pts = b.delete(pts, ~valid)
    curves = b.node("GeometryNodePointsToCurves", {"Points": pts, "Curve Group ID": b.named("ap_id", "INT"),
                                                  "Weight": k}).out(0)
    count = b.node("GeometryNodeSplineLength")["Point Count"]
    curves = b.delete(curves, count < 3, domain="CURVE")
    curves = b.node("GeometryNodeSetSplineCyclic", [curves, True, True]).out(0)
    mesh = fill(b, curves)
    return b.node("GeometryNodeMergeByDistance", {"Geometry": mesh, "Distance": 1e-7}).out(0)


# ----------------------------------------------------------------------
def build_family(fam, groups):
    t = new_tree(fam.tree_name, modifier=True)
    t.description = f"{fam.name} ({fam.group}). Driven: {fam.drive} Making it: {fam.make}"
    add_socket(t, "Geometry", "GEO")
    add_socket(t, "Geometry", "GEO", out=True)
    I = t.interface
    p = I.new_panel("Pattern")
    add_socket(t, "Cell Size", "FLOAT", default=0.024, lo=0.0005, subtype="DISTANCE", panel=p,
               desc="Grid pitch, or the typical spacing for seeded patterns")
    add_socket(t, "Seed", "INT", default=7, panel=p)
    if fam.align:
        add_socket(t, "Align", "BOOL", default=False, panel=p, desc="Follow the attractor direction")
    for name, kind, default in fam.extra:
        add_socket(t, name, kind, default=default, panel=p)
    p = I.new_panel("Attractors")
    add_socket(t, "Attractor Points", "COLL", panel=p, desc="Collection of empties (their origins attract)")
    add_socket(t, "Attractor Lines", "COLL", panel=p, desc="Collection of curves or meshes (their edges attract)")
    add_socket(t, "Radius", "FLOAT", default=0.22, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Influence radius: the field fades to zero at this distance")
    add_socket(t, "Falloff", "MENU", panel=p)
    add_socket(t, "Combine", "MENU", panel=p)
    add_socket(t, "Invert", "BOOL", default=False, panel=p)
    p = I.new_panel("Fabrication")
    add_socket(t, "Min Bridge", "FLOAT", default=0.002, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Minimum web of material between openings")
    add_socket(t, "Min Hole", "FLOAT", default=0.002, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Openings smaller than this are removed, not shrunk")
    add_socket(t, "Edge Margin", "FLOAT", default=0.008, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Solid border kept along the mesh's open edges and holes")
    add_socket(t, "Corner Radius", "FLOAT", default=0.001, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Fillet on sharp corners, for laser and waterjet")
    p = I.new_panel("Output")
    add_socket(t, "Mode", "MENU", panel=p)
    add_socket(t, "Thickness", "FLOAT", default=0.0015, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Sheet thickness: open surfaces are thickened by this, and cuts go this deep")
    add_socket(t, "Depth", "FLOAT", default=0.001, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Engrave depth or emboss height")
    add_socket(t, "UV Map", "STR", default="UVMap", panel=p)
    add_socket(t, "UV Scale", "FLOAT", default=0.0, lo=0.0, subtype="DISTANCE", panel=p,
               desc="Real length of one UV unit. 0 measures it from the mesh")

    b = Builder(t)
    gi, go = io(b)
    falloff = menu(b, gi, "Falloff", core.FALLOFFS)
    combine = menu(b, gi, "Combine", core.COMBINES)
    mode = menu(b, gi, "Mode", core.MODES)
    plane = b.group(groups["uv_plane"], {"Mesh": gi["Geometry"], "UV Map": gi["UV Map"],
                                         "UV Scale": gi["UV Scale"]})
    c = Ctx(b, gi, groups, plane)
    c.falloff, c.combine = falloff, combine
    shapes = fam.recipe(c)
    ap = b.group(groups["apply"], {
        "Shapes": shapes, "Solid": fam.solid, "Drop Islands": fam.drop_islands, "Mesh": gi["Geometry"],
        "UV Map": gi["UV Map"], "Scale": c.S, "Boundary": plane["Boundary"],
        "Boundary Edges": plane["Boundary Edges"], "Edge Margin": gi["Edge Margin"], "Mode": mode,
        "Thickness": gi["Thickness"], "Depth": gi["Depth"], "Attractor Points": gi["Attractor Points"],
        "Attractor Lines": gi["Attractor Lines"], "Radius": gi["Radius"], "Falloff": falloff,
        "Combine": combine, "Invert": gi["Invert"]})
    b.set(go, "Geometry", ap["Geometry"])
    # menu defaults can only be set once the sockets are linked to their switches
    for name, val in (("Falloff", "Smooth"), ("Combine", "Max"), ("Mode", "Preview")):
        for it in t.interface.items_tree:
            if getattr(it, "name", None) == name and getattr(it, "in_out", None) == "INPUT":
                try:
                    it.default_value = val
                except (TypeError, AttributeError):
                    pass
    b.layout()
    return t


def build_all():
    falloff = core.build_falloff()
    field = core.build_field(falloff)
    surface = core.build_surface()
    groups = {
        "falloff": falloff,
        "field": field,
        "surface": surface,
        "uv_plane": core.build_uv_plane(),
        "cells": core.build_cells(),
        "sample": core.build_sample(surface, field),
        "shell": core.build_shell(),
    }
    groups["apply"] = core.build_apply(surface, groups["shell"], field)
    trees = {}
    for fam in FAMILIES:
        trees[fam.key] = build_family(fam, groups)
    return trees
