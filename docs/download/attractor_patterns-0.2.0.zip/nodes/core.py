"""Shared node groups: attractor field, UV mapping, cell grids and the cut / engrave / emboss stage.

Every pattern works in the "pattern plane": the object's UV map scaled to real
units, so a cell size of 24 mm means 24 mm on the surface. Shapes are built
flat in that plane, then every vertex is projected back onto the surface with
Sample UV Surface. The attractor field is always measured in 3D, in the
object's local space, against empties (points) and curves or mesh edges (lines).
"""

import math

from .dsl import Builder, new_tree, add_socket, io

PREFIX = "AP "
FALLOFFS = ["Smooth", "Linear", "Gaussian", "Inverse Square", "Stepped"]
COMBINES = ["Max", "Sum"]
MODES = ["Cut Through", "Engrave", "Emboss", "Preview"]
BIG = 1.0e9


def _tree(name):
    return new_tree(PREFIX + name)


# ----------------------------------------------------------------------
def build_falloff():
    """Distance -> 0..1, same five curves as the playground's fallOf()."""
    t = _tree("Falloff")
    add_socket(t, "Distance", "FLOAT")
    add_socket(t, "Radius", "FLOAT", default=1.0)
    add_socket(t, "Falloff", "INT", default=0, lo=0, hi=4)
    add_socket(t, "Value", "FLOAT", out=True)
    b = Builder(t)
    gi, go = io(b)
    d, R = gi["Distance"], b.maxf(gi["Radius"], 1e-9)
    u = b.clamp(d / R)
    smooth = 1.0 - u * u * (3.0 - u * 2.0)
    lin = 1.0 - u
    gauss = b.switch(u >= 1.0, b.math("EXPONENT", u * u * -4.5), 0.0)
    q = d / (R * 0.25)
    inv = 1.0 / (q * q + 1.0)
    step = b.math("CEIL", lin * 4.0) / 4.0
    v = b.index_switch(gi["Falloff"], [smooth, lin, gauss, inv, step])
    b.set(go, "Value", v)
    b.layout()
    return t


def _repeat(b, geo, iterations, items):
    """Create a repeat zone carrying Geometry plus single-value items.
    Returns (zone_in N, zone_out N). zone_in outputs: Geometry, items...; feed zone_out."""
    ri = b.nodes.new("GeometryNodeRepeatInput")
    ro = b.nodes.new("GeometryNodeRepeatOutput")
    ri.pair_with_output(ro)
    for kind, name in items:
        ro.repeat_items.new(kind, name)
    b._order += [ri, ro]
    from .dsl import N
    zi, zo = N(b, ri), N(b, ro)
    b.set(zi, "Iterations", iterations)
    b.set(zi, "Geometry", geo)
    return zi, zo


def build_field(falloff):
    """Geometry in -> same geometry with point attributes ap_field, ap_dir, ap_dist.

    ap_field: 0..1 strength (combined over all attractors, clamped, optionally inverted)
    ap_dir:   unit vector from the nearest attractor to the point
    ap_dist:  distance to the nearest attractor
    """
    t = _tree("Field")
    add_socket(t, "Geometry", "GEO")
    add_socket(t, "Points", "COLL", desc="Empties or any objects; their origins are point attractors")
    add_socket(t, "Lines", "COLL", desc="Curves or meshes; their edges are line attractors")
    add_socket(t, "Radius", "FLOAT", default=0.22, lo=0.0, subtype="DISTANCE")
    add_socket(t, "Falloff", "INT", default=0, lo=0, hi=4)
    add_socket(t, "Combine", "INT", default=0, lo=0, hi=1)
    add_socket(t, "Invert", "BOOL", default=False)
    add_socket(t, "Geometry", "GEO", out=True)
    b = Builder(t)
    gi, go = io(b)

    geo = b.store(gi["Geometry"], "ap_acc", 0.0)
    geo = b.store(geo, "ap_dist", BIG)
    geo = b.store(geo, "ap_dir", (1.0, 0.0, 0.0), kind="FLOAT_VECTOR")

    def accumulate(geo, dist, near_pos):
        v = b.group(falloff, {"Distance": dist, "Radius": gi["Radius"], "Falloff": gi["Falloff"]}).out(0)
        acc = b.named("ap_acc")
        new_acc = b.switch(b.cmp("EQUAL", gi["Combine"], 0, dtype="INT"), acc + v, b.maxf(acc, v))
        geo = b.store(geo, "ap_acc", new_acc)
        closer = dist < b.named("ap_dist")
        d = b.normalize(b.position() - near_pos)
        geo = b.store(geo, "ap_dir", d, kind="FLOAT_VECTOR", selection=closer)
        geo = b.store(geo, "ap_dist", dist, selection=closer)
        return geo

    # point attractors: one loop step per object origin
    pts = b.node("GeometryNodeCollectionInfo", {"Collection": gi["Points"], "Separate Children": True,
                                               "Reset Children": False}, transform_space="RELATIVE")
    pts = b.node("GeometryNodeInstancesToPoints", {"Instances": pts}).out(0)
    npts = b.node("GeometryNodeAttributeDomainSize", {"Geometry": pts}, component="POINTCLOUD")["Point Count"]
    zi, zo = _repeat(b, geo, npts, [("INT", "i")])
    i = zi["i"]
    p = b.sample_index(pts, b.position(), i, kind="FLOAT_VECTOR")
    dist = b.vmath("DISTANCE", b.position(), p)
    g = accumulate(zi["Geometry"], dist, p)
    b.set(zo, "Geometry", g)
    b.set(zo, "i", i + 1)
    geo = zo["Geometry"]

    # line attractors: one loop step per object, distance to its edges
    lines = b.node("GeometryNodeCollectionInfo", {"Collection": gi["Lines"], "Separate Children": True,
                                                 "Reset Children": False}, transform_space="RELATIVE").out(0)
    nl = b.node("GeometryNodeAttributeDomainSize", {"Geometry": lines}, component="INSTANCES")["Instance Count"]
    zi, zo = _repeat(b, geo, nl, [("INT", "i")])
    i = zi["i"]
    one = b.delete(lines, b.cmp("NOT_EQUAL", b.index(), i, dtype="INT"), domain="INSTANCE")
    one = b.node("GeometryNodeRealizeInstances", {"Geometry": one}).out(0)
    comps = b.node("GeometryNodeSeparateComponents", {"Geometry": one})
    as_mesh = b.join(comps["Mesh"], b.node("GeometryNodeCurveToMesh", {"Curve": comps["Curve"]}).out(0))
    prox = b.node("GeometryNodeProximity", {"Geometry": as_mesh}, target_element="EDGES")
    b.set(prox, "Sample Position", b.position())
    g = accumulate(zi["Geometry"], prox["Distance"], prox["Position"])
    b.set(zo, "Geometry", g)
    b.set(zo, "i", i + 1)
    geo = zo["Geometry"]

    f = b.clamp(b.named("ap_acc"))
    f = b.switch(gi["Invert"], f, 1.0 - f)
    geo = b.store(geo, "ap_field", f)
    geo = b.node("GeometryNodeRemoveAttribute", {"Geometry": geo, "Name": "ap_acc"}).out(0)
    b.set(go, "Geometry", geo)
    b.layout()
    return t


# ----------------------------------------------------------------------
def build_surface():
    """Field group: pattern-plane point P -> surface position, normal, validity and UV tangents."""
    t = _tree("Surface")
    add_socket(t, "Mesh", "GEO")
    add_socket(t, "UV Map", "STR", default="UVMap")
    add_socket(t, "Scale", "FLOAT", default=1.0)
    add_socket(t, "P", "VEC", field=True)
    add_socket(t, "Position", "VEC", out=True)
    add_socket(t, "Normal", "VEC", out=True)
    add_socket(t, "Valid", "BOOL", out=True)
    add_socket(t, "Tangent U", "VEC", out=True)
    add_socket(t, "Tangent V", "VEC", out=True)
    b = Builder(t)
    gi, go = io(b)
    uv = b.named(gi["UV Map"], "FLOAT_VECTOR")
    S = gi["Scale"]
    suv = gi["P"] / S

    def sample(value, at):
        n = b.node("GeometryNodeSampleUVSurface", {"Mesh": gi["Mesh"], "Value": value, "Sample UV": at},
                   data_type="FLOAT_VECTOR")
        b.set(n, "UV Map" if "UV Map" in [s.name for s in n.node.inputs] else "Source UV Map", uv)
        return n

    pos = sample(b.position(), suv)
    nrm = sample(b.normal(), suv)
    eps = 1.0e-4
    pu = sample(b.position(), suv + (eps, 0.0, 0.0))
    pv = sample(b.position(), suv + (0.0, eps, 0.0))
    b.set(go, "Position", pos.out(0))
    b.set(go, "Normal", b.normalize(nrm.out(0)))
    b.set(go, "Valid", pos["Is Valid"])
    b.set(go, "Tangent U", (pu.out(0) - pos.out(0)) / (S * eps))
    b.set(go, "Tangent V", (pv.out(0) - pos.out(0)) / (S * eps))
    b.layout()
    return t


def build_uv_plane():
    """Flatten the mesh onto its UV map at real scale.

    Outputs the flat mesh (point attribute ap_world = original position), the
    scale (world length per UV unit, auto from area unless overridden), the
    flat bounding box, and the mesh's open boundary edges for the edge margin.
    """
    t = _tree("UV Plane")
    add_socket(t, "Mesh", "GEO")
    add_socket(t, "UV Map", "STR", default="UVMap")
    add_socket(t, "UV Scale", "FLOAT", default=0.0, lo=0.0, subtype="DISTANCE")
    add_socket(t, "Plane", "GEO", out=True)
    add_socket(t, "Scale", "FLOAT", out=True)
    add_socket(t, "Min", "VEC", out=True)
    add_socket(t, "Max", "VEC", out=True)
    add_socket(t, "Boundary", "GEO", out=True)
    add_socket(t, "Boundary Edges", "INT", out=True)
    b = Builder(t)
    gi, go = io(b)
    mesh = b.node("GeometryNodeSeparateComponents", {"Geometry": gi["Mesh"]})["Mesh"]
    area = b.node("GeometryNodeInputMeshFaceArea").out(0)
    a3 = b.stat(mesh, area, domain="FACE")["Sum"]
    flat = b.store(mesh, "ap_world", b.position(), kind="FLOAT_VECTOR")
    flat = b.node("GeometryNodeSplitEdges", {"Mesh": flat}).out(0)
    uv = b.named(gi["UV Map"], "FLOAT_VECTOR")
    uvp = b.on_domain(uv, "CORNER", kind="FLOAT_VECTOR")
    # after splitting every edge each vertex has exactly one corner, so point = corner value
    flat = b.set_pos(flat, b.vec(uvp.x, uvp.y, 0.0))
    auv = b.stat(flat, b.node("GeometryNodeInputMeshFaceArea").out(0), domain="FACE")["Sum"]
    auto = b.sqrt(a3 / b.maxf(auv, 1e-12))
    S = b.switch(gi["UV Scale"] > 0.0, auto, gi["UV Scale"])
    flat = b.node("GeometryNodeTransform", {"Geometry": flat, "Scale": b.vec(S, S, 1.0)}).out(0)
    flat = b.node("GeometryNodeMergeByDistance", {"Geometry": flat, "Distance": S * 1e-7}).out(0)
    bb = b.node("GeometryNodeBoundBox", {"Geometry": flat})
    nb = b.node("GeometryNodeInputMeshEdgeNeighbors")["Face Count"]
    border = b.node("GeometryNodeMeshToCurve", {"Mesh": mesh, "Selection": b.cmp("EQUAL", nb, 1, dtype="INT")})
    border = b.node("GeometryNodeCurveToMesh", {"Curve": border}).out(0)
    ne = b.node("GeometryNodeAttributeDomainSize", {"Geometry": border}, component="MESH")["Edge Count"]
    for k, v in (("Plane", flat), ("Scale", S), ("Min", bb["Min"]), ("Max", bb["Max"]),
                 ("Boundary", border), ("Boundary Edges", ne)):
        b.set(go, k, v)
    b.layout()
    return t


def build_cells():
    """Cell centres in the pattern plane: square grid, hex grid, or hex grid with half rows (diamonds)."""
    t = _tree("Cells")
    add_socket(t, "Min", "VEC")
    add_socket(t, "Max", "VEC")
    add_socket(t, "Cell Size", "FLOAT", default=0.024)
    add_socket(t, "Grid", "INT", default=0, desc="0 square, 1 hex, 2 hex with half-height rows")
    add_socket(t, "Points", "GEO", out=True)
    b = Builder(t)
    gi, go = io(b)
    s = b.maxf(gi["Cell Size"], 1e-6)
    x0, y0 = gi["Min"].x, gi["Min"].y
    x1, y1 = gi["Max"].x, gi["Max"].y
    grid = gi["Grid"]
    is_sq = b.cmp("EQUAL", grid, 0, dtype="INT")
    h = b.switch(b.cmp("EQUAL", grid, 2, dtype="INT"), s * (math.sqrt(3) / 2), s / 2.0)
    # square: centres from x0+s/2 while <= x1;  hex: from x0 (odd rows +s/2) while <= x1+s, rows while <= y1+h
    nx = b.switch(is_sq, b.floor((x1 - x0 + s) / s) + 1.0, b.floor((x1 - x0 - s / 2.0) / s) + 1.0)
    ny = b.switch(is_sq, b.floor((y1 - y0 + h) / h) + 1.0, b.floor((y1 - y0 - s / 2.0) / s) + 1.0)
    nx = b.clamp(nx, 1.0, 600.0)
    ny = b.clamp(ny, 1.0, 600.0)
    nxi = b.node("FunctionNodeFloatToInt", {"Float": nx}, rounding_mode="ROUND").out(0)
    count = b.node("FunctionNodeFloatToInt", {"Float": nx * ny}, rounding_mode="ROUND").out(0)
    idx = b.index()
    i = b.mod(idx, nxi)
    j = b.floor(idx / nxi)
    odd = b.mod(j, 2.0)
    px = b.switch(is_sq, x0 + odd * s / 2.0 + i * s, x0 + s / 2.0 + i * s)
    py = b.switch(is_sq, y0 + j * h, y0 + s / 2.0 + j * s)
    pts = b.node("GeometryNodePoints", {"Count": count, "Position": b.vec(px, py, 0.0)}).out(0)
    b.set(go, "Points", pts)
    b.layout()
    return t


def build_sample(surface, field):
    """Pattern-plane points -> attach the attractor field.

    Adds ap_field, ap_dir2 (field direction in the pattern plane, pointing away
    from the nearest attractor) and ap_tan2 (perpendicular to it). Points that
    fall outside the UV islands are removed. Positions stay in the plane.
    """
    t = _tree("Sample Field")
    add_socket(t, "Points", "GEO")
    add_socket(t, "Mesh", "GEO")
    add_socket(t, "UV Map", "STR", default="UVMap")
    add_socket(t, "Scale", "FLOAT", default=1.0)
    add_socket(t, "Attractor Points", "COLL")
    add_socket(t, "Attractor Lines", "COLL")
    add_socket(t, "Radius", "FLOAT", default=0.22)
    add_socket(t, "Falloff", "INT", default=0)
    add_socket(t, "Combine", "INT", default=0)
    add_socket(t, "Invert", "BOOL", default=False)
    add_socket(t, "Remove Invalid", "BOOL", default=True)
    add_socket(t, "Points", "GEO", out=True)
    b = Builder(t)
    gi, go = io(b)
    sf = b.group(surface, {"Mesh": gi["Mesh"], "UV Map": gi["UV Map"], "Scale": gi["Scale"], "P": b.position()})
    geo = b.store(gi["Points"], "ap_uvp", b.position(), kind="FLOAT_VECTOR")
    geo = b.store(geo, "ap_tu", sf["Tangent U"], kind="FLOAT_VECTOR")
    geo = b.store(geo, "ap_tv", sf["Tangent V"], kind="FLOAT_VECTOR")
    geo = b.store(geo, "ap_valid", sf["Valid"], kind="BOOLEAN")
    geo = b.set_pos(geo, sf["Position"])
    geo = b.delete(geo, ~b.named("ap_valid", "BOOLEAN") & gi["Remove Invalid"])
    geo = b.group(field, {"Geometry": geo, "Points": gi["Attractor Points"], "Lines": gi["Attractor Lines"],
                          "Radius": gi["Radius"], "Falloff": gi["Falloff"], "Combine": gi["Combine"],
                          "Invert": gi["Invert"]}).out(0)
    d = b.named("ap_dir", "FLOAT_VECTOR")
    tu, tv = b.named("ap_tu", "FLOAT_VECTOR"), b.named("ap_tv", "FLOAT_VECTOR")
    du = b.dot(d, tu) / b.maxf(b.dot(tu, tu), 1e-12)
    dv = b.dot(d, tv) / b.maxf(b.dot(tv, tv), 1e-12)
    d2 = b.normalize(b.vec(du, dv, 0.0))
    geo = b.store(geo, "ap_dir2", d2, kind="FLOAT_VECTOR")
    geo = b.store(geo, "ap_tan2", b.vec(-d2.y, d2.x, 0.0), kind="FLOAT_VECTOR")
    geo = b.set_pos(geo, b.named("ap_uvp", "FLOAT_VECTOR"))
    b.set(go, "Points", geo)
    b.layout()
    return t


# ----------------------------------------------------------------------
def build_shell():
    """Close an open surface into a shell of the given thickness, growing along -normal."""
    t = _tree("Shell")
    add_socket(t, "Mesh", "GEO")
    add_socket(t, "Thickness", "FLOAT", default=0.0015)
    add_socket(t, "Normal", "VEC", field=True)
    add_socket(t, "Mesh", "GEO", out=True)
    b = Builder(t)
    gi, go = io(b)
    ex = b.node("GeometryNodeExtrudeMesh", {"Mesh": gi["Mesh"], "Offset": gi["Normal"] * -1.0,
                                            "Offset Scale": gi["Thickness"], "Individual": False}, mode="FACES")
    flipped = b.node("GeometryNodeFlipFaces", {"Mesh": ex["Mesh"]}).out(0)
    joined = b.join(gi["Mesh"], flipped)
    merged = b.node("GeometryNodeMergeByDistance", {"Geometry": joined, "Distance": 1e-6}).out(0)
    b.set(go, "Mesh", merged)
    b.layout()
    return t


def build_apply(surface, shell, field):
    """Map flat pattern shapes onto the surface and cut, engrave, emboss or preview them.

    Shapes: mesh in the pattern plane (z = 0). Optional point attribute ap_lift
    lifts a vertex along the surface normal (jewel apexes). With Solid on, the
    shapes are closed solids already and are not extruded.
    """
    t = _tree("Apply")
    add_socket(t, "Shapes", "GEO")
    add_socket(t, "Solid", "BOOL", default=False)
    add_socket(t, "Drop Islands", "BOOL", default=True)
    add_socket(t, "Mesh", "GEO")
    add_socket(t, "UV Map", "STR", default="UVMap")
    add_socket(t, "Scale", "FLOAT", default=1.0)
    add_socket(t, "Boundary", "GEO")
    add_socket(t, "Boundary Edges", "INT")
    add_socket(t, "Edge Margin", "FLOAT", default=0.008)
    add_socket(t, "Mode", "INT", default=0)
    add_socket(t, "Thickness", "FLOAT", default=0.0015)
    add_socket(t, "Depth", "FLOAT", default=0.001)
    add_socket(t, "Attractor Points", "COLL")
    add_socket(t, "Attractor Lines", "COLL")
    add_socket(t, "Radius", "FLOAT", default=0.22)
    add_socket(t, "Falloff", "INT", default=0)
    add_socket(t, "Combine", "INT", default=0)
    add_socket(t, "Invert", "BOOL", default=False)
    add_socket(t, "Geometry", "GEO", out=True)
    add_socket(t, "Pattern", "GEO", out=True)
    b = Builder(t)
    gi, go = io(b)
    S = gi["Scale"]
    eps = S * 2.0e-5 + 1.0e-6
    # solids (jewel studs) can only be added or engraved; "cut through" adds them
    mode = b.switch(gi["Solid"] & b.cmp("EQUAL", gi["Mode"], 0, dtype="INT"), gi["Mode"], 2, kind="INT")
    is_engrave = b.cmp("EQUAL", mode, 1, dtype="INT")

    sf = b.group(surface, {"Mesh": gi["Mesh"], "UV Map": gi["UV Map"], "Scale": S, "P": b.position()})
    shapes = b.store(gi["Shapes"], "ap_n", sf["Normal"], kind="FLOAT_VECTOR")
    shapes = b.store(shapes, "ap_ok", sf["Valid"], kind="BOOLEAN")
    lift = b.named("ap_lift") * b.switch(is_engrave, 1.0, -1.0)
    shapes = b.set_pos(shapes, sf["Position"] + sf["Normal"] * lift)

    # edge margin: distance from the mesh's open boundary (none on closed meshes)
    prox = b.node("GeometryNodeProximity", {"Geometry": gi["Boundary"]}, target_element="EDGES")
    b.set(prox, "Sample Position", b.position())
    far = b.cmp("EQUAL", gi["Boundary Edges"], 0, dtype="INT") | (prox["Distance"] >= gi["Edge Margin"])
    bad = ~(b.named("ap_ok", "BOOLEAN") & far)
    island = b.node("GeometryNodeInputMeshIsland")["Island Index"]
    acc = b.node("GeometryNodeAccumulateField", {"Value": b.switch(bad, 0.0, 1.0), "Group ID": island},
                 data_type="FLOAT", domain="POINT")["Total"]
    kill = b.switch(gi["Drop Islands"], bad, acc > 0.0, kind="BOOLEAN")
    shapes = b.delete(shapes, kill)
    n = b.named("ap_n", "FLOAT_VECTOR")

    # flat shapes become prisms: cut runs through the sheet, engrave goes Depth down, emboss Depth up
    up = b.index_switch(mode, [eps, eps, gi["Depth"], eps])
    down = b.index_switch(mode, [gi["Thickness"] + eps, gi["Depth"], eps, eps])
    bottom = b.set_pos(shapes, offset=n * (down * -1.0))
    ex = b.node("GeometryNodeExtrudeMesh", {"Mesh": bottom, "Offset": n, "Offset Scale": up + down,
                                            "Individual": False}, mode="FACES")
    prism = b.join(ex["Mesh"], b.node("GeometryNodeFlipFaces", {"Mesh": bottom}).out(0))
    prism = b.node("GeometryNodeMergeByDistance", {"Geometry": prism, "Distance": eps * 0.01}).out(0)
    # solids: sink the base slightly so the union / difference is clean; engraved solids are mirrored
    solid = b.set_pos(shapes, offset=n * b.switch(is_engrave, eps * -1.0, eps))
    solid = b.switch(is_engrave, solid, b.node("GeometryNodeFlipFaces", {"Mesh": solid}).out(0), kind="GEOMETRY")
    cutters = b.switch(gi["Solid"], prism, solid, kind="GEOMETRY")

    target = b.node("GeometryNodeSeparateComponents", {"Geometry": gi["Mesh"]})["Mesh"]
    closed = b.cmp("EQUAL", gi["Boundary Edges"], 0, dtype="INT")
    shell = b.group(shell, {"Mesh": target, "Thickness": gi["Thickness"], "Normal": b.normal()}).out(0)
    body = b.switch(closed, shell, target, kind="GEOMETRY")

    def boolean(op):
        """Manifold solver when available (fast); fall back to Exact if it rejects the input."""
        def make(solver):
            n = b.node("GeometryNodeMeshBoolean", operation=op, solver=solver)
            if op == "DIFFERENCE":
                b.set(n, "Mesh 1", body)
            else:
                b.set(n, "Mesh 2", body)
            b.set(n, "Mesh 2", cutters)
            return n.out(0)
        fast = _solver(b)
        out = make(fast)
        if fast == "EXACT":
            return out
        faces = b.node("GeometryNodeAttributeDomainSize", {"Geometry": out}, component="MESH")["Face Count"]
        return b.switch(b.cmp("EQUAL", faces, 0, dtype="INT"), out, make("EXACT"), kind="GEOMETRY")

    diff, uni = boolean("DIFFERENCE"), boolean("UNION")

    preview_pat = b.set_pos(shapes, offset=n * eps * 10.0)
    preview_pat = b.group(field, {"Geometry": preview_pat, "Points": gi["Attractor Points"],
                                  "Lines": gi["Attractor Lines"], "Radius": gi["Radius"], "Falloff": gi["Falloff"],
                                  "Combine": gi["Combine"], "Invert": gi["Invert"]}).out(0)
    mat = b.node("GeometryNodeSetMaterial", {"Geometry": preview_pat})
    mat.node.inputs["Material"].default_value = preview_material()
    preview = b.join(gi["Mesh"], mat.out(0))
    out = b.index_switch(mode, [diff, diff, uni, preview], kind="GEOMETRY")
    b.set(go, "Geometry", out)
    b.set(go, "Pattern", preview_pat)
    b.layout()
    return t


def preview_material():
    """Material for Preview mode: ap_field through the playground's blue-yellow-orange-red ramp."""
    import bpy
    name = "AP Field"
    m = bpy.data.materials.get(name)
    if m is not None:
        return m
    m = bpy.data.materials.new(name)
    if not m.node_tree:
        m.use_nodes = True
    nt = m.node_tree
    bsdf = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
    attr = nt.nodes.new("ShaderNodeAttribute")
    attr.attribute_name = "ap_field"
    attr.location = (-600, 200)
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    ramp.location = (-350, 200)
    el = ramp.color_ramp.elements
    stops = [(0.0, (37, 99, 235)), (0.4, (250, 204, 21)), (0.7, (249, 115, 22)), (1.0, (220, 38, 38))]
    el[0].position, el[1].position = stops[0][0], stops[-1][0]
    for pos, _ in stops[1:-1]:
        el.new(pos)
    for e, (pos, rgb) in zip(sorted(el, key=lambda e: e.position), stops):
        e.color = tuple((c / 255.0) ** 2.2 for c in rgb) + (1.0,)
    nt.links.new(attr.outputs["Fac"], ramp.inputs["Fac"])
    nt.links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    m.diffuse_color = (0.9, 0.5, 0.2, 1.0)
    return m


def _solver(b):
    import bpy
    items = bpy.types.GeometryNodeMeshBoolean.bl_rna.properties["solver"].enum_items.keys()
    return "MANIFOLD" if "MANIFOLD" in items else "EXACT"


# ----------------------------------------------------------------------
# shape helpers used inside pattern trees

def poly_shapes(b, cells, n, point_fn, fillet=None, fillet_count=4):
    """One closed polygon of n vertices per cell.

    point_fn(k) receives the vertex index (0..n-1, a field) and returns the
    vertex offset from the cell centre in the pattern plane. Cell attributes
    (ap_field, ap_dir2, ...) are readable with b.named() inside point_fn.
    Returns a flat mesh with one triangulated face group per cell.
    """
    cells = b.store(cells, "ap_id", b.index(), kind="INT")
    dup = b.node("GeometryNodeDuplicateElements", {"Geometry": cells, "Amount": n}, domain="POINT")
    pts = b.store(dup["Geometry"], "ap_k", dup["Duplicate Index"], kind="INT")
    k = b.named("ap_k", "INT")
    pts = b.set_pos(pts, offset=point_fn(k))
    curves = b.node("GeometryNodePointsToCurves", {"Points": pts, "Curve Group ID": b.named("ap_id", "INT"),
                                                  "Weight": k}).out(0)
    curves = b.node("GeometryNodeSetSplineCyclic", [curves, True, True]).out(0)
    return fill(b, curves, fillet, fillet_count)


def fill(b, curves, fillet=None, count=4):
    if fillet is not None:
        fc = b.node("GeometryNodeFilletCurve", {"Curve": curves, "Radius": fillet, "Limit Radius": True},
                    mode="POLY")
        b.set(fc, "Count", count)
        curves = fc.out(0)
    gid = b.on_domain(b.index(), "CURVE", kind="INT")
    return b.node("GeometryNodeFillCurve", {"Curve": curves, "Group ID": gid}, mode="TRIANGLES").out(0)


def cell_drop(b, cells, keep):
    """Remove cells where keep is False (shape too small, below min hole...)."""
    return b.delete(cells, ~keep)
