"""Small helpers that hide API differences between Blender 4.2 and 5.x."""


def input_ids(tree):
    return {it.name: it for it in tree.interface.items_tree
            if getattr(it, "item_type", "") == "SOCKET" and it.in_out == "INPUT"}


def set_input(mod, name, value):
    """Set a Geometry Nodes modifier input by its socket name."""
    item = input_ids(mod.node_group)[name]
    ident = item.identifier
    if hasattr(mod, "properties") and hasattr(mod.properties, "inputs"):  # Blender 5.x
        getattr(mod.properties.inputs, ident).value = value
        return
    if item.socket_type == "NodeSocketMenu" and isinstance(value, str):  # 4.2 stores menus as ints
        items = mod.id_properties_ui(ident).as_dict().get("items", [])
        value = next(i[4] for i in items if i[0] == value)
    mod[ident] = value


def get_input(mod, name):
    ident = input_ids(mod.node_group)[name].identifier
    if hasattr(mod, "properties") and hasattr(mod.properties, "inputs"):
        return getattr(mod.properties.inputs, ident).value
    return mod[ident]

