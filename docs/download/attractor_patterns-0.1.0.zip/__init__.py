"""Attractor Patterns: perforations, textures and cutouts on any object, driven by point and line attractors.

Adds a Patterns tab to the 3D View sidebar. Each pattern is a Geometry Nodes
modifier ("AP Honeycomb", "AP Voronoi Cells", ...) built from Python, so the
node groups live in your .blend like any other and keep working without the
add-on once added.
"""

import bpy
from bpy.props import EnumProperty

from . import compat
from .nodes import patterns

VERSION = (0, 1, 0)
TAG = "ap_version"
POINTS, LINES = "AP Attractor Points", "AP Attractor Lines"


def _groups_current():
    for fam in patterns.FAMILIES:
        t = bpy.data.node_groups.get(fam.tree_name)
        if t is None or tuple(t.get(TAG, ())) != VERSION:
            return False
    return True


def ensure_groups(force=False):
    if force or not _groups_current():
        trees = patterns.build_all()
        for t in bpy.data.node_groups:
            if t.name.startswith("AP "):
                t[TAG] = VERSION
        return trees
    return {f.key: bpy.data.node_groups[f.tree_name] for f in patterns.FAMILIES}


def _collection(name):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(c)
    return c


def _family_items(self, context):
    return [(f.key, f.name, f"{f.group}. {f.drive}") for f in patterns.FAMILIES]


class AP_OT_add_pattern(bpy.types.Operator):
    """Add an attractor pattern modifier to the active mesh"""
    bl_idname = "attractor_patterns.add_pattern"
    bl_label = "Add Pattern"
    bl_options = {"REGISTER", "UNDO"}

    family: EnumProperty(name="Pattern", items=_family_items)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH"

    def execute(self, context):
        o = context.active_object
        if not o.data.uv_layers:
            self.report({"WARNING"}, "This mesh has no UV map. Unwrap it first (Smart UV Project or "
                                     "Project from View keep real proportions).")
            return {"CANCELLED"}
        trees = ensure_groups()
        tree = trees[self.family]
        m = o.modifiers.new(tree.name, "NODES")
        m.node_group = tree
        compat.set_input(m, "Attractor Points", _collection(POINTS))
        compat.set_input(m, "Attractor Lines", _collection(LINES))
        compat.set_input(m, "UV Map", o.data.uv_layers.active.name)
        # scale the defaults to the object: about 25 cells across its longest side
        size = max(o.dimensions) or 1.0
        unit = size / 26.7  # the playground: 640 mm sheet, 24 mm cells
        for name, k in (("Cell Size", 1.0), ("Radius", 220 / 24), ("Min Bridge", 2 / 24), ("Min Hole", 2 / 24),
                        ("Edge Margin", 8 / 24), ("Corner Radius", 1 / 24), ("Thickness", 1.5 / 24),
                        ("Depth", 1 / 24)):
            compat.set_input(m, name, unit * k)
        if not _collection(POINTS).objects and not _collection(LINES).objects:
            self.report({"INFO"}, "Add a point or line attractor to shape the pattern.")
        return {"FINISHED"}


class AP_OT_add_attractor(bpy.types.Operator):
    """Add a point attractor (an empty) or a line attractor (a curve) at the 3D cursor"""
    bl_idname = "attractor_patterns.add_attractor"
    bl_label = "Add Attractor"
    bl_options = {"REGISTER", "UNDO"}

    kind: EnumProperty(name="Kind", items=[("POINT", "Point", "An empty; its origin attracts"),
                                           ("LINE", "Line", "A curve; its whole length attracts")])

    def execute(self, context):
        loc = context.scene.cursor.location.copy()
        target = context.active_object
        size = max(target.dimensions) if target else 1.0
        if self.kind == "POINT":
            ob = bpy.data.objects.new("Point Attractor", None)
            ob.empty_display_type = "SPHERE"
            ob.empty_display_size = size * 0.03
            _collection(POINTS).objects.link(ob)
        else:
            cu = bpy.data.curves.new("Line Attractor", "CURVE")
            cu.dimensions = "3D"
            sp = cu.splines.new("POLY")
            sp.points.add(1)
            sp.points[0].co = (-size * 0.3, 0, 0, 1)
            sp.points[1].co = (size * 0.3, 0, 0, 1)
            ob = bpy.data.objects.new("Line Attractor", cu)
            _collection(LINES).objects.link(ob)
        ob.location = loc
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        return {"FINISHED"}


class AP_OT_rebuild(bpy.types.Operator):
    """Rebuild the pattern node groups in this file from the installed add-on version"""
    bl_idname = "attractor_patterns.rebuild"
    bl_label = "Rebuild Node Groups"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        # keep the modifiers pointing at the rebuilt trees, with their settings
        saved = []
        for o in bpy.data.objects:
            for m in getattr(o, "modifiers", []):
                if m.type == "NODES" and m.node_group and m.node_group.name.startswith("AP "):
                    vals = {}
                    for name in compat.input_ids(m.node_group):
                        try:
                            vals[name] = compat.get_input(m, name)
                        except Exception:
                            pass
                    saved.append((m, m.node_group.name, vals))
        ensure_groups(force=True)
        for m, name, vals in saved:
            m.node_group = bpy.data.node_groups[name]
            for k, v in vals.items():
                try:
                    compat.set_input(m, k, v)
                except Exception:
                    pass
        self.report({"INFO"}, f"Rebuilt {len(patterns.FAMILIES)} patterns")
        return {"FINISHED"}


class AP_PT_panel(bpy.types.Panel):
    bl_label = "Attractor Patterns"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Patterns"

    def draw(self, context):
        lay = self.layout
        col = lay.column(align=True)
        col.label(text="Attractors")
        row = col.row(align=True)
        row.operator(AP_OT_add_attractor.bl_idname, text="Point", icon="EMPTY_AXIS").kind = "POINT"
        row.operator(AP_OT_add_attractor.bl_idname, text="Line", icon="CURVE_PATH").kind = "LINE"
        lay.separator()
        o = context.active_object
        if o is None or o.type != "MESH":
            lay.label(text="Select a mesh to add a pattern", icon="INFO")
        else:
            lay.label(text=f"Add to {o.name}")
            grid = lay.grid_flow(columns=2, even_columns=True, align=True)
            for f in patterns.FAMILIES:
                grid.operator(AP_OT_add_pattern.bl_idname, text=f.name).family = f.key
        lay.separator()
        lay.operator(AP_OT_rebuild.bl_idname, icon="FILE_REFRESH")


classes = (AP_OT_add_pattern, AP_OT_add_attractor, AP_OT_rebuild, AP_PT_panel)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
