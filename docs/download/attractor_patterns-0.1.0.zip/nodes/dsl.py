"""A small builder for Geometry Nodes trees.

Node groups are generated from Python rather than shipped as a binary .blend,
so they stay diffable and work across Blender versions. The builder papers over
the API differences between Blender 4.2 (enum properties on nodes) and 5.x
(many of those became Menu input sockets).

Sockets are wrapped in `S`, which overloads arithmetic so pattern recipes read
close to the playground's JavaScript:  r = (s - b) / 2 * f
"""

import bpy

FLOAT_TYPES = {"VALUE", "INT", "BOOLEAN"}

# prop name -> socket name, for nodes whose enum became a Menu socket in 5.x
_SOCKET_NAMES = {"ngon_method": "N-gon Method"}


def _label(enum_id):
    return enum_id.replace("_", " ").title()


class S:
    """An output socket (or constant) that supports math operators."""

    def __init__(self, b, sock):
        self.b, self.sock = b, sock

    @property
    def is_vec(self):
        return self.sock.type in ("VECTOR",)

    # float/vector arithmetic --------------------------------------------
    def _bin(self, other, fop, vop, rev=False):
        a, c = (other, self) if rev else (self, other)
        av = isinstance(a, S) and a.is_vec or isinstance(a, tuple)
        cv = isinstance(c, S) and c.is_vec or isinstance(c, tuple)
        if av or cv:
            if vop == "MULTIPLY" and not (av and cv):
                vec, sc = (a, c) if av else (c, a)
                return self.b.vmath("SCALE", vec, scale=sc)
            if vop == "DIVIDE" and av and not cv:
                return self.b.vmath("SCALE", a, scale=self.b.math("DIVIDE", 1.0, c))
            return self.b.vmath(vop, a, c)
        return self.b.math(fop, a, c)

    def __add__(self, o): return self._bin(o, "ADD", "ADD")
    def __radd__(self, o): return self._bin(o, "ADD", "ADD", True)
    def __sub__(self, o): return self._bin(o, "SUBTRACT", "SUBTRACT")
    def __rsub__(self, o): return self._bin(o, "SUBTRACT", "SUBTRACT", True)
    def __mul__(self, o): return self._bin(o, "MULTIPLY", "MULTIPLY")
    def __rmul__(self, o): return self._bin(o, "MULTIPLY", "MULTIPLY", True)
    def __truediv__(self, o): return self._bin(o, "DIVIDE", "DIVIDE")
    def __rtruediv__(self, o): return self._bin(o, "DIVIDE", "DIVIDE", True)
    def __pow__(self, o): return self.b.math("POWER", self, o)
    def __neg__(self):
        return self.b.vmath("SCALE", self, scale=-1.0) if self.is_vec else self.b.math("MULTIPLY", self, -1.0)

    # comparisons return boolean sockets
    def __lt__(self, o): return self.b.cmp("LESS_THAN", self, o)
    def __le__(self, o): return self.b.cmp("LESS_EQUAL", self, o)
    def __gt__(self, o): return self.b.cmp("GREATER_THAN", self, o)
    def __ge__(self, o): return self.b.cmp("GREATER_EQUAL", self, o)
    def __and__(self, o): return self.b.boolop("AND", self, o)
    def __or__(self, o): return self.b.boolop("OR", self, o)
    def __invert__(self): return self.b.boolop("NOT", self)

    # vector components
    @property
    def x(self): return self.b.sep(self)[0]
    @property
    def y(self): return self.b.sep(self)[1]
    @property
    def z(self): return self.b.sep(self)[2]


class N:
    """A node; index or call to get outputs."""

    def __init__(self, b, node):
        self.b, self.node = b, node

    def out(self, key=0):
        outs = [s for s in self.node.outputs if s.enabled and s.type != "CUSTOM"]
        if isinstance(key, int):
            return S(self.b, outs[key])
        for s in outs:
            if s.name == key:
                return S(self.b, s)
        raise KeyError(f"{self.node.bl_idname} has no output {key!r}: {[s.name for s in outs]}")

    __getitem__ = out


class Builder:
    def __init__(self, tree):
        self.tree = tree
        self.nodes = tree.nodes
        self.links = tree.links
        self._sep_cache = {}
        self._order = []

    # ------------------------------------------------------------------
    def opt(self, node, prop, value):
        """Set an enum option that is a property in 4.2 and a Menu socket in 5.x."""
        if hasattr(node, prop):
            setattr(node, prop, value)
            return
        name = _SOCKET_NAMES.get(prop, _label(prop))
        for s in node.inputs:
            if s.name == name and s.type == "MENU":
                want = "".join(ch for ch in value.lower() if ch.isalnum())
                items = [i.name for i in s.bl_rna.properties["default_value"].enum_items_static] or []
                try:
                    items = [i.name for i in s.bl_rna.properties["default_value"].enum_items] or items
                except Exception:
                    pass
                for it in items:
                    if "".join(ch for ch in it.lower() if ch.isalnum()) == want:
                        s.default_value = it
                        return
                s.default_value = _label(value)
                return
        raise AttributeError(f"{node.bl_idname}: no option {prop}")

    def _input(self, node, key):
        ins = [s for s in node.inputs if s.enabled and s.type != "CUSTOM"]
        if isinstance(key, int):
            return ins[key]
        for s in ins:
            if s.name == key or s.identifier == key:
                return s
        raise KeyError(f"{node.bl_idname} has no input {key!r}: {[s.name for s in ins]}")

    def set(self, node, key, value):
        sock = self._input(node.node if isinstance(node, N) else node, key)
        self.connect(value, sock)

    def connect(self, value, sock):
        if value is None:
            return
        if isinstance(value, N):
            value = value.out(0)
        if isinstance(value, S):
            self.links.new(value.sock, sock)
        else:
            if sock.type == "VECTOR" and not isinstance(value, (tuple, list)):
                value = (value, value, value)
            sock.default_value = value

    def node(self, idname, inputs=None, label=None, **props):
        n = self.nodes.new(idname)
        self._order.append(n)
        if label:
            n.label = label
        for k, v in props.items():
            self.opt(n, k, v)
        if inputs:
            items = inputs.items() if isinstance(inputs, dict) else enumerate(inputs)
            for k, v in items:
                self.set(n, k, v)
        return N(self, n)

    # math -------------------------------------------------------------
    def math(self, op, a, c=None, d=None):
        n = self.node("ShaderNodeMath", operation=op)
        ins = [s for s in n.node.inputs]
        for sock, v in zip(ins, (a, c, d)):
            if v is not None:
                self.connect(v, sock)
        return n.out(0)

    def vmath(self, op, a, c=None, d=None, scale=None):
        n = self.node("ShaderNodeVectorMath", operation=op)
        ins = [s for s in n.node.inputs]
        for sock, v in zip(ins[:3], (a, c, d)):
            if v is not None:
                self.connect(v, sock)
        if scale is not None:
            self.connect(scale, n.node.inputs["Scale"])
        if op in ("DOT_PRODUCT", "LENGTH", "DISTANCE"):
            return n.out("Value")
        return n.out("Vector")

    def cmp(self, op, a, c, dtype="FLOAT"):
        n = self.node("FunctionNodeCompare", data_type=dtype, operation=op)
        self.connect(a, self._input(n.node, 0))
        self.connect(c, self._input(n.node, 1))
        return n.out(0)

    def boolop(self, op, a, c=None):
        n = self.node("FunctionNodeBooleanMath", operation=op)
        ins = list(n.node.inputs)
        self.connect(a, ins[0])
        if c is not None:
            self.connect(c, ins[1])
        return n.out(0)

    def vec(self, x=0.0, y=0.0, z=0.0):
        return self.node("ShaderNodeCombineXYZ", [x, y, z]).out(0)

    def sep(self, v):
        key = v.sock.as_pointer() if isinstance(v, S) else None
        if key in self._sep_cache:
            return self._sep_cache[key]
        n = self.node("ShaderNodeSeparateXYZ", [v])
        r = (n.out(0), n.out(1), n.out(2))
        if key is not None:
            self._sep_cache[key] = r
        return r

    def lerp(self, a, c, t):
        return a + (c - a) * t if isinstance(a, S) or isinstance(c, S) else (c - a) * t + a

    def clamp(self, v, lo=0.0, hi=1.0):
        return self.node("ShaderNodeClamp", {"Value": v, "Min": lo, "Max": hi}).out(0)

    def minf(self, a, c): return self.math("MINIMUM", a, c)
    def maxf(self, a, c): return self.math("MAXIMUM", a, c)
    def floor(self, a): return self.math("FLOOR", a)
    def sqrt(self, a): return self.math("SQRT", a)
    def sin(self, a): return self.math("SINE", a)
    def cos(self, a): return self.math("COSINE", a)
    def atan2(self, y, x): return self.math("ARCTAN2", y, x)
    def absf(self, a): return self.math("ABSOLUTE", a)
    def sign(self, a): return self.math("SIGN", a)
    def mod(self, a, c): return self.math("FLOORED_MODULO", a, c)
    def length(self, v): return self.vmath("LENGTH", v)
    def dot(self, a, c): return self.vmath("DOT_PRODUCT", a, c)
    def normalize(self, v): return self.vmath("NORMALIZE", v)
    def cross(self, a, c): return self.vmath("CROSS_PRODUCT", a, c)

    def switch(self, cond, false, true, kind="FLOAT"):
        n = self.node("GeometryNodeSwitch", input_type=kind)
        self.set(n, "Switch", cond)
        self.set(n, "False", false)
        self.set(n, "True", true)
        return n.out(0)

    def index_switch(self, index, items, kind="FLOAT"):
        n = self.node("GeometryNodeIndexSwitch", data_type=kind)
        while len([s for s in n.node.inputs if s.type != "CUSTOM"]) - 1 < len(items):
            n.node.index_switch_items.new()
        self.set(n, "Index", index)
        ins = [s for s in n.node.inputs if s.type != "CUSTOM"][1:]
        for sock, v in zip(ins, items):
            self.connect(v, sock)
        return n.out(0)

    # common inputs ------------------------------------------------------
    def position(self): return self.node("GeometryNodeInputPosition").out(0)
    def index(self): return self.node("GeometryNodeInputIndex").out(0)
    def normal(self): return self.node("GeometryNodeInputNormal").out(0)

    def named(self, name, kind="FLOAT"):
        return self.node("GeometryNodeInputNamedAttribute", {"Name": name}, data_type=kind).out(0)

    def store(self, geo, name, value, kind="FLOAT", domain="POINT", selection=None):
        n = self.node("GeometryNodeStoreNamedAttribute", data_type=kind, domain=domain)
        self.set(n, "Geometry", geo)
        self.set(n, "Name", name)
        self.set(n, "Value", value)
        if selection is not None:
            self.set(n, "Selection", selection)
        return n.out(0)

    def stat(self, geo, value, domain="POINT", selection=None):
        n = self.node("GeometryNodeAttributeStatistic", data_type="FLOAT", domain=domain)
        self.set(n, "Geometry", geo)
        self.set(n, "Attribute", value)
        if selection is not None:
            self.set(n, "Selection", selection)
        return n

    def set_pos(self, geo, pos=None, offset=None, selection=None):
        n = self.node("GeometryNodeSetPosition", {"Geometry": geo})
        if pos is not None:
            self.set(n, "Position", pos)
        if offset is not None:
            self.set(n, "Offset", offset)
        if selection is not None:
            self.set(n, "Selection", selection)
        return n.out(0)

    def delete(self, geo, selection, domain="POINT", mode="ALL"):
        return self.node("GeometryNodeDeleteGeometry", {"Geometry": geo, "Selection": selection},
                         domain=domain, mode=mode).out(0)

    def join(self, *geos):
        n = self.node("GeometryNodeJoinGeometry")
        sock = n.node.inputs[0]
        for g in reversed(geos):
            self.connect(g, sock)
        return n.out(0)

    def sample_index(self, geo, value, index, kind="FLOAT", domain="POINT"):
        return self.node("GeometryNodeSampleIndex", {"Geometry": geo, "Value": value, "Index": index},
                         data_type=kind, domain=domain).out(0)

    def on_domain(self, value, domain, kind="FLOAT"):
        return self.node("GeometryNodeFieldOnDomain", {"Value": value}, domain=domain, data_type=kind).out(0)

    def random(self, lo, hi, id_, seed, kind="FLOAT"):
        return self.node("FunctionNodeRandomValue", {"Min": lo, "Max": hi, "ID": id_, "Seed": seed},
                         data_type=kind).out(0)

    def group(self, tree, inputs=None):
        n = self.node("GeometryNodeGroup")
        n.node.node_tree = tree
        if inputs:
            for k, v in inputs.items():
                self.set(n, k, v)
        return n

    # layout ---------------------------------------------------------------
    def layout(self):
        """Place nodes in columns by link depth so the tree is readable when opened."""
        depth = {n: 0 for n in self.nodes}
        changed = True
        for _ in range(len(depth)):
            if not changed:
                break
            changed = False
            for l in self.links:
                a, c = l.from_node, l.to_node
                if depth[c] < depth[a] + 1:
                    depth[c] = depth[a] + 1
                    changed = True
        cols = {}
        for n in self.nodes:
            if n.bl_idname == "NodeFrame":
                continue
            cols.setdefault(depth[n], []).append(n)
        for d, ns in cols.items():
            y = 0
            for n in ns:
                n.location = (d * 220, -y)
                y += 60 + 22 * (len([s for s in n.inputs if s.enabled and not s.hide]) +
                                len([s for s in n.outputs if s.enabled]))


# ----------------------------------------------------------------------
# group interface helpers

def new_tree(name, modifier=False):
    t = bpy.data.node_groups.get(name)
    if t is not None:
        bpy.data.node_groups.remove(t)
    t = bpy.data.node_groups.new(name, "GeometryNodeTree")
    if modifier and hasattr(t, "is_modifier"):
        t.is_modifier = True
    return t


_SOCK = {
    "GEO": "NodeSocketGeometry", "FLOAT": "NodeSocketFloat", "INT": "NodeSocketInt",
    "BOOL": "NodeSocketBool", "VEC": "NodeSocketVector", "STR": "NodeSocketString",
    "COLL": "NodeSocketCollection", "IMG": "NodeSocketImage", "MENU": "NodeSocketMenu",
    "OBJ": "NodeSocketObject",
}


def add_socket(tree, name, kind, out=False, default=None, lo=None, hi=None, subtype=None,
               panel=None, desc="", field=False, single=False):
    s = tree.interface.new_socket(name, in_out="OUTPUT" if out else "INPUT",
                                  socket_type=_SOCK[kind], parent=panel)
    s.description = desc
    if default is not None and hasattr(s, "default_value"):
        s.default_value = default
    if lo is not None and hasattr(s, "min_value"):
        s.min_value = lo
    if hi is not None and hasattr(s, "max_value"):
        s.max_value = hi
    if subtype and hasattr(s, "subtype"):
        try:
            s.subtype = subtype
        except TypeError:
            pass
    if single and hasattr(s, "force_non_field"):
        s.force_non_field = True
    if single and hasattr(s, "structure_type"):
        try:
            s.structure_type = "SINGLE"
        except TypeError:
            pass
    return s


def io(b):
    gi = b.node("NodeGroupInput")
    go = b.node("NodeGroupOutput")
    return gi, go


def menu(b, gi, name, items, kind="INT", values=None):
    """Turn a group Menu input into an integer (or other) value via Menu Switch."""
    n = b.node("GeometryNodeMenuSwitch", data_type=kind)
    ms = n.node
    while len(ms.enum_items) < len(items):
        ms.enum_items.new("x")
    for it, label in zip(ms.enum_items, items):
        it.name = label
    vals = values or list(range(len(items)))
    ins = [s for s in ms.inputs if s.type != "CUSTOM"]
    b.connect(gi[name], ins[0])
    for sock, v in zip(ins[1:], vals):
        b.connect(v, sock)
    return n.out(0)
